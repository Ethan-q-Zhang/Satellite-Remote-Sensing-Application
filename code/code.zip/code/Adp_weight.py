import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.neural_network import MLPRegressor
from numpy.random import dirichlet
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 黑体


class AdaptiveWeightCalculator:
    def __init__(self, data, initial_weights=None):
        """
        初始化自适应权重计算器

        参数:
            data: 包含年份和各项指标数据的DataFrame
            initial_weights: 可选，初始权重字典，如未提供将自动计算
        """

        self.df = data.copy()
        self.years = data['年份'].values
        self.indicators = [col for col in data.columns if col != '年份']
        if initial_weights is None:
            # self.initial_weights = self.entropy_weight_method(data[self.indicators])
            self.initial_weights = self.entropy_weight_method(data[self.indicators])
        else:
            self.initial_weights = np.array(list(initial_weights.values()))

    def entropy_weight_method(self, data):
        """熵权法计算初始权重"""
        # 标准化处理
        # data_norm1 = data.apply(lambda x: (x - x.min()) / (x.max() - x.min()), axis=0)  #(数据已经标准化) axis=0:按列归一化
        data_norm = data
        # 计算比重
        p = data_norm.div(data_norm.sum(axis=1), axis=0)   # .sum(axis=1)行求和，.div(, axis=0)

        # 计算熵值
        k = 1 / np.log(len(data.columns))
        # tttt = len(data.columns)
        # te = p * np.log(p)
        # tee = (p * np.log(p)).sum(axis=1)
        e = -k * (p * np.log(p)).sum(axis=1)
        e = e.replace([np.inf, -np.inf, np.nan], 0)  # 处理异常值

        # 计算权重
        d = 1 - e
        aaaa = d.sum()
        w = d / d.sum()

        return w.values

    def adaptive_least_squares(self, lambda_param=0.5):
        """最小二乘自适应模型"""
        # X = self.df[self.indicators].values[:-1]  # 使用前n-1年作为训练数据
        X = self.df[self.indicators].values.T[:-1]  # 使用前n-1年作为训练数据
        # print(len(X))
        # print(X.shape[1])
        # y = np.ones(len(X))  # 假设综合得分为1
        y = np.ones(X.shape[1])  # 假设综合得分为1
        # 定义目标函数
        def objective(w):
            pred = X.dot(w)
            return np.sum((y - pred) ** 2) + lambda_param * np.sum((w - self.initial_weights) ** 2)

        # 定义约束条件
        constraints = ({'type': 'eq', 'fun': lambda w: np.sum(w) - 1})
        bounds = [(0, 1) for _ in range(len(self.initial_weights))]

        # 优化求解
        result = minimize(objective, self.initial_weights, method='SLSQP',
                          bounds=bounds, constraints=constraints)

        return result.x

    def adaptive_ml_model(self, alpha=0.1):
        """基于机器学习的自适应模型"""
        X = []
        y = []

        # 构建时间序列特征
        for i in range(1, len(self.years)):
            prev_data = self.df[self.indicators].iloc[i - 1].values
            current_data = self.df[self.indicators].iloc[i].values
            X.append(prev_data)
            y.append(current_data - prev_data)  # 预测变化量

        X = np.array(X)
        y = np.array(y)

        # 训练神经网络模型
        model = MLPRegressor(hidden_layer_sizes=(20, 10), activation='relu',
                             max_iter=1000, random_state=42)
        model.fit(X, y)

        # 预测下一年的变化
        last_data = self.df[self.indicators].iloc[-2].values.reshape(1, -1)
        delta_pred = model.predict(last_data)[0]

        # 结合初始权重进行调整
        new_weights = self.initial_weights + alpha * delta_pred
        new_weights = np.clip(new_weights, 0, 1)  # 限制在0-1之间
        new_weights = new_weights / new_weights.sum()  # 归一化

        return new_weights

    def adaptive_bayesian(self, n_samples=1000):
        """贝叶斯动态权重模型（简化版）"""
        # 计算各指标的变化趋势作为伪计数
        trends = self.df[self.indicators].diff().mean().values
        alpha = self.initial_weights * 100 + trends * 10  # 调整超参数

        # 从Dirichlet分布中采样
        samples = dirichlet(alpha, size=n_samples)
        new_weights = samples.mean(axis=0)

        return new_weights

    def calculate_all_methods(self):
        """计算所有方法的权重"""
        return {
            'initial': self.initial_weights,
            'least_squares': self.adaptive_least_squares(),
            'ml_model': self.adaptive_ml_model(),
            'bayesian': self.adaptive_bayesian()
        }

    def visualize_weights(self, weights_dict=None):
        """可视化权重比较"""
        if weights_dict is None:
            weights_dict = self.calculate_all_methods()

        plt.figure(figsize=(12, 6))
        x = np.arange(len(self.indicators))
        width = 0.2

        for i, (method, weights) in enumerate(weights_dict.items()):
            plt.bar(x + (i - 1.5) * width, weights, width, label=method)

        plt.xlabel('指标')
        plt.ylabel('权重')
        plt.title('不同方法的权重调整结果')
        plt.xticks(x, self.indicators, rotation=45, ha='right')
        plt.legend()
        plt.tight_layout()
        plt.show()


# 测试用例
if __name__ == "__main__":

    # 读取特定工作表或列
    df_sheet2 = pd.read_excel('D:\study\Revisepaper\Paperdata\论文数据2025V2.xlsx', sheet_name='珠海初始权重')
    # 准备测试数据
    # test_data = {
    #     '年份': [2015, 2016, 2017, 2018, 2019, 2020, 2021],
    #     'GDP/亿元': [0.0001, 0.1086, 0.2908, 0.4793, 0.76, 0.7848, 1.0001],
    #     '人口/万人': [0.0001, 0.0496, 0.1578, 0.3088, 0.468, 0.9796, 1.0001],
    #     '财政收入': [0.0001, 0.1751, 0.2431, 0.1972, 0.1384, 0.3172, 1.0001]
    # }


    # test_data = df_sheet2.iloc[0:10, 0:8]
    test_data = df_sheet2.iloc[11:22, 0:8]
    test_weights = None
    calculator = AdaptiveWeightCalculator(pd.DataFrame(test_data), test_weights)

    # 计算并打印各种方法的权重
    results = calculator.calculate_all_methods()
    for method, weights in results.items():
        print(f"{method} weights:", dict(zip(calculator.indicators, weights)))

    # # 可视化结果
    # calculator.visualize_weights()
