import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# 使用您提供的数据
group1 = [
    [0.0738, 0.3373, 0.0511, 0.0818, 0.0848, 0.0758, 0.1165, 0.0515, 0.0417, 0.0432, 0.0425],
    [0.0286, 0.3689, 0.0037, 0.0362, 0.1178, 0.1157, 0.1356, 0.0418, 0.0599, 0.0442, 0.0476]
]

group2 = [
    [0.0847, 0.2286, 0.0472, 0.0689, 0.0782, 0.0784, 0.1546, 0.0691, 0.1006, 0.0453, 0.0444],
    [0.0624, 0.2019, 0.0094, 0.0293, 0.1016, 0.1066, 0.1588, 0.0894, 0.1494, 0.0328, 0.0584]
]

group3 = [
    [0.0671, 0.0597, 0.0978, 0.0696, 0.0806, 0.0865, 0.1905, 0.1578, 0.0918, 0.0507, 0.0479],
    [0.0331, 0.0297, 0.1316, 0.0246, 0.0589, 0.1043, 0.1827, 0.1889, 0.1231, 0.0620, 0.0611]
]

# 获取数据的列数（变量数量）
num_columns = len(group1[0])

# 准备数据
data = []
groups = []
variables = []

# 为每个变量和组准备数据
for i in range(num_columns):
    # Group 1
    data.append(group1[0][i])
    groups.append('Group 1 (Shanghai)')
    variables.append(f'X{i + 1}')

    data.append(group1[1][i])
    groups.append('Group 1 (Shanghai)')
    variables.append(f'X{i + 1}')

    # Group 2
    data.append(group2[0][i])
    groups.append('Group 2 (Shanghai)')
    variables.append(f'X{i + 1}')

    data.append(group2[1][i])
    groups.append('Group 2 (Shanghai)')
    variables.append(f'X{i + 1}')

    # Group 3
    data.append(group3[0][i])
    groups.append('Group 3 (Zhuhai)')
    variables.append(f'X{i + 1}')

    data.append(group3[1][i])
    groups.append('Group 3 (Zhuhai)')
    variables.append(f'X{i + 1}')

# 创建DataFrame
df = pd.DataFrame({
    'Value': data,
    'Group': groups,
    'Variable': variables
})

# 创建图形
fig, ax = plt.subplots(figsize=(18, 8))

# 设置颜色
colors = ['#FF6B6B', '#4D96FF', '#6BCF7F']  # 红色、蓝色、绿色

# 使用seaborn绘制小提琴图
# 由于每组只有2个点，我们设置bw_method='silverman'以获得更好的展示
sns.violinplot(data=df, x='Variable', y='Value', hue='Group',
               palette=colors, split=False, ax=ax, inner='box',
               bw_method=0.5, cut=0, linewidth=1)  # 调整带宽和线宽

# 添加实际数据点
sns.stripplot(data=df, x='Variable', y='Value', hue='Group',
              palette=colors, ax=ax, dodge=True, jitter=True,
              size=8, edgecolor='black', linewidth=0.5, alpha=0.7)

# 设置标题和标签
ax.set_title('Violin Plot of Three Groups (with Data Points)', fontsize=16, pad=20)
ax.set_xlabel('Variable Index', fontsize=12)
ax.set_ylabel('Value', fontsize=12)

# 自适应y轴范围
y_min_raw, y_max_raw = min(data), max(data)
y_min = 0
y_max = y_max_raw * 1.1
ax.set_ylim(y_min, y_max)

# 添加网格
ax.yaxis.grid(True, linestyle='--', alpha=0.3, linewidth=0.5)
ax.set_axisbelow(True)

# 调整图例
handles, labels = ax.get_legend_handles_labels()
# 移除重复的图例
unique_labels = []
unique_handles = []
for handle, label in zip(handles, labels):
    if label not in unique_labels:
        unique_labels.append(label)
        unique_handles.append(handle)
ax.legend(unique_handles, unique_labels, title='Groups', loc='upper right')

# 添加统计信息文本框
stats_text = f"""Statistics Summary (N={num_columns} variables):
Group 1 Mean: {np.mean(group1[0] + group1[1]):.4f}
Group 2 Mean: {np.mean(group2[0] + group2[1]):.4f}
Group 3 Mean: {np.mean(group3[0] + group3[1]):.4f}"""

ax.text(0.02, 0.98, stats_text, transform=ax.transAxes, fontsize=9,
        verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# 调整布局
plt.tight_layout()

# 显示图形
plt.show()

# 保存图片
plt.savefig('violin_plot_with_points.png', dpi=300, bbox_inches='tight')
print(f"Violin plot saved as 'violin_plot_with_points.png' (with {num_columns} variables)")

# 输出数据统计信息
print("\n=== 数据统计信息 ===")
print(
    f"Group 1 (Shanghai): 平均值 = {np.mean(group1[0] + group1[1]):.4f}, 标准差 = {np.std(group1[0] + group1[1]):.4f}")
print(
    f"Group 2 (Shanghai): 平均值 = {np.mean(group2[0] + group2[1]):.4f}, 标准差 = {np.std(group2[0] + group2[1]):.4f}")
print(f"Group 3 (Zhuhai): 平均值 = {np.mean(group3[0] + group3[1]):.4f}, 标准差 = {np.std(group3[0] + group3[1]):.4f}")