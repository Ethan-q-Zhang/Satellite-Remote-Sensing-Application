import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# 数据：上海
# row1 = [0.0879, 0.2143, 0.0564, 0.0971, 0.0769, 0.1083, 0.0673, 0.1, 0.0879, 0.0966]
# row2 = [0.0937, 0.2275, 0.0725, 0.1117, 0.0842, 0.1159, 0.0175, 0.1, 0.0993, 0.0605]
row1 = [0.0847, 0.2286, 0.0472, 0.0689, 0.0782, 0.0784, 0.1546, 0.1, 0.1006, 0.0453, 0.0444]
row2 = [0.0624, 0.2019, 0.0094, 0.0293, 0.1016, 0.1066, 0.1588, 0.1, 0.1494, 0.0328, 0.0584]

#数据：珠海
# row1 = [0.0982, 0.1415, 0.1354, 0.0947, 0.0826, 0.0655, 0.0857, 0.1, 0.0982, 0.1031]
# row2 = [0.1127, 0.1619, 0.1504, 0.1065, 0.0939, 0.0497, 0.0767, 0.1, 0.0986, 0.0503]
# row3 = [0.0671, 0.0597, 0.0978, 0.0696, 0.0806, 0.0865, 0.1905, 0.2, 0.0918, 0.0507, 0.0479]
# row4 = [0.0331, 0.0297, 0.1316, 0.0246, 0.0589, 0.1043, 0.1827, 0.2, 0.1231, 0.062, 0.0611]

#数据：青岛
row1 = [0.095, 0.1492, 0.0669, 0.101, 0.0699, 0.0801, 0.1306, 0.1, 0.0951, 0.0872]
row2 = [0.1102, 0.163, 0.0853, 0.1081, 0.0704, 0.09, 0.1018, 0.1, 0.1105, 0.0473]
row3 = [0.0738, 0.3373, 0.0511, 0.0818, 0.0848, 0.0758, 0.1165, 0.1, 0.0417, 0.0432, 0.0425]
row4 = [0.0286, 0.3689, 0.0037, 0.0362, 0.1178, 0.1157, 0.1356, 0, 0.0599, 0.0442, 0.0476]

# 将数据重新组织为每列一组
columns_data = []
column_names = []
for i in range(len(row1)):
    columns_data.append([row1[i], row2[i]])
    column_names.append(f'X{i+1}')

# 创建箱形图
fig, ax = plt.subplots(figsize=(10, 6))

# 定义细线样式
thin_linewidth = 0.8  # 细线宽度

# 绘制箱形图，设置所有线体为细线
bp = ax.boxplot(columns_data, labels=column_names,
                patch_artist=False,  # 无色填充
                notch=False,  # 不显示凹口
                showmeans=True,  # 显示均值
                boxprops=dict(color='black', linewidth=thin_linewidth),  # 箱体边框细线
                whiskerprops=dict(color='black', linewidth=thin_linewidth),  # 须线细线
                capprops=dict(color='black', linewidth=thin_linewidth),  # 箱体两端线细线
                medianprops=dict(color='red', linewidth=thin_linewidth),  # 中位数线细线
                flierprops=dict(marker='o', markerfacecolor='none',
                               markeredgecolor='black', markersize=6,
                               markeredgewidth=thin_linewidth/2, alpha=0.6),  # 离群点细线
                meanprops=dict(marker='o', markerfacecolor='green',
                              markeredgecolor='green', markersize=4,
                              markeredgewidth=thin_linewidth/2))  # 均值点细线边框

# 设置坐标轴（使用英文标签避免字体问题）
ax.set_ylabel('Weight Value', fontsize=10)
ax.set_xlabel('Variable Index', fontsize=10)
# ax.set_title('Boxplot for Each Column (Left: Initial, Right: Optimized)', fontsize=14, pad=20)

# 添加网格
ax.yaxis.grid(True, linestyle='--', alpha=0.7, linewidth=0.5)
ax.set_axisbelow(True)

# 设置y轴范围
ax.set_ylim(0, 0.25)
ax.set_yticks([0, 0.05, 0.10, 0.15, 0.20, 0.25])

# 旋转x轴标签
plt.setp(ax.get_xticklabels(), rotation=45, ha='right')

# 创建自定义图例句柄（使用细线）
legend_elements = [
    Patch(facecolor='none', edgecolor='black', linewidth=thin_linewidth, label='Box'),
    Line2D([0], [0], color='red', linewidth=thin_linewidth, label='Median'),
    Line2D([0], [0], marker='o', color='w', markerfacecolor='green',
           markeredgecolor='green', markersize=4,
           markeredgewidth=thin_linewidth/2, label='Mean')
]
ax.legend(handles=legend_elements, loc='upper right')

# 计算并显示每列的统计信息
print("Statistical Information for Each Column:")
print("="*70)
for i, col in enumerate(columns_data):
    col_data = np.array(col)
    mean_val = np.mean(col_data)
    std_val = np.std(col_data)
    print(f"X{i+1}: Initial={row1[i]:.4f}, Optimized={row2[i]:.4f}, Difference={row2[i]-row1[i]:.4f}, Mean={mean_val:.4f}, Std={std_val:.4f}")

# 计算总体统计
print("\nOverall Statistical Information:")
print("="*70)
print(f"Initial Values: Mean={np.mean(row1):.4f}, Std={np.std(row1):.4f}, Min={min(row1):.4f}, Max={max(row1):.4f}")
print(f"Optimized Values: Mean={np.mean(row2):.4f}, Std={np.std(row2):.4f}, Min={min(row2):.4f}, Max={max(row2):.4f}")

# 找出变化最大的列
differences = [abs(row2[i] - row1[i]) for i in range(len(row1))]
max_diff_idx = np.argmax(differences)
max_diff = differences[max_diff_idx]
print(f"\nLargest Change: X{max_diff_idx+1} (Change={max_diff:.4f})")

# 计算变化方向统计
pos_changes = sum(1 for i in range(len(row1)) if row2[i] > row1[i])
neg_changes = sum(1 for i in range(len(row1)) if row2[i] < row1[i])
zero_changes = sum(1 for i in range(len(row1)) if row2[i] == row1[i])
print(f"Change Direction: Positive={pos_changes}, Negative={neg_changes}, Zero={zero_changes}")

# 调整布局
plt.tight_layout()

# 保存图片
plt.savefig('seeq.png', dpi=300, bbox_inches='tight')
print("\nBoxplot saved as 'seeq.png'")

# 显示图形
plt.show()