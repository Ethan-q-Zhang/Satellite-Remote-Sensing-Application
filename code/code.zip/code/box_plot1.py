import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# 使用您提供的真实数据
# udl
# 青岛
# group1 = [
#     [0.095, 0.1492, 0.0872, 0.0951, 0.0669, 0.101, 0.0801, 0.0699, 0.1306, 0.125],
#     [0.1102, 0.163, 0.0473, 0.1105, 0.0853, 0.1081, 0.09, 0.0704, 0.1018, 0.1134]
# ]
# #上海
# group2 = [
#     [0.0879, 0.2143, 0.0966, 0.0879, 0.0564, 0.0971, 0.1083, 0.0769, 0.0673, 0.1073],
#     [0.0937, 0.2275, 0.0605, 0.0993, 0.0725, 0.1117, 0.1159, 0.0842, 0.0175, 0.1172]
# ]
# #珠海
# group3 = [
#     [0.0982, 0.1415, 0.1031, 0.0982, 0.1354, 0.0947, 0.0655, 0.0826, 0.0857, 0.0951],
#     [0.1127, 0.1619, 0.0503, 0.0986, 0.1504, 0.1065, 0.0497, 0.0939, 0.0767, 0.0993]
# ]
# eeq
# 青岛
group1 = [
    [0.0738, 0.3373, 0.0511, 0.1165, 0.0515, 0.0417, 0.0432, 0.0425, 0.0758, 0.0818, 0.0848],
    [0.0286, 0.3689, 0.0037, 0.1356, 0.0418, 0.0599, 0.0442, 0.0476, 0.1157, 0.0362, 0.1178]
]
#上海
group2 = [
    [0.0847, 0.2286, 0.0472, 0.1546, 0.0691, 0.1006, 0.0453, 0.0444, 0.0784, 0.0689, 0.0782],
    [0.0624, 0.2019, 0.0094, 0.1588, 0.0894, 0.1494, 0.0328, 0.0584, 0.1066, 0.0293, 0.1016]
]
#珠海
group3 = [
    [0.0671, 0.0597, 0.0978, 0.1905, 0.1578, 0.0918, 0.0507, 0.0479, 0.0865, 0.0696, 0.0806],
    [0.0331, 0.0297, 0.1316, 0.1827, 0.1889, 0.1231, 0.062, 0.0611, 0.1043, 0.0246, 0.0589]
]

# 创建箱形图
fig, ax = plt.subplots(figsize=(14, 8))

# 定义细线样式
thin_linewidth = 0.8

# 获取数据的列数（变量数量）
num_columns = len(group1[0])

# 准备数据位置和箱形图数据
positions = []
all_data = []
colors = []

# 为每个变量创建三组箱形图
# 使用更鲜明的颜色：红色、蓝色、绿色
for i in range(num_columns):
    # 第一组数据（红色）
    positions.append(i * 4 + 1)
    all_data.append([group1[0][i], group1[1][i]])  # 每组两个值
    colors.append('#FF0000')  # 红色

    # 第二组数据（蓝色）
    positions.append(i * 4 + 2)
    all_data.append([group2[0][i], group2[1][i]])  # 每组两个值
    colors.append('#0066CC')  # 蓝色

    # 第三组数据（绿色）
    positions.append(i * 4 + 3)
    all_data.append([group3[0][i], group3[1][i]])  # 每组两个值
    colors.append('#009900')  # 绿色

# 绘制箱形图
bp = ax.boxplot(all_data, positions=positions, widths=0.8,
                patch_artist=True,
                notch=False,
                showmeans=True,
                boxprops=dict(linewidth=thin_linewidth),
                whiskerprops=dict(linewidth=thin_linewidth),
                capprops=dict(linewidth=thin_linewidth),
                medianprops=dict(color='red', linewidth=thin_linewidth * 1.2),
                flierprops=dict(marker='o', markerfacecolor='none',
                                markersize=5, markeredgewidth=thin_linewidth / 2, alpha=0.6),
                meanprops=dict(marker='o', markerfacecolor='none',  # markerfacecolor='green'
                               markeredgecolor='none', markersize=4,  # markeredgecolor='green'
                               markeredgewidth=thin_linewidth / 2))

# 设置箱体颜色
for box, color in zip(bp['boxes'], colors):
    box.set(color=color)
    box.set_facecolor(color + '20')  # 添加透明度
    box.set_linewidth(thin_linewidth)

# 修正X轴显示：设置x轴标签和刻度
x_ticks = np.arange(2, num_columns*4, 4)
ax.set_xticks(x_ticks)
ax.set_xticklabels([f'X{i + 11}' for i in range(num_columns)])

# 设置坐标轴标签
ax.set_ylabel('Weight Value', fontsize=14)
ax.set_xlabel('Indicator', fontsize=14)  # 单行X轴标签
# ax.set_title('Boxplot Comparison of Three Groups (G1, G2, G3)', fontsize=14, pad=20)

# 添加网格
ax.yaxis.grid(True, linestyle='--', alpha=0.3, linewidth=0.5)
ax.set_axisbelow(True)

# 设置y轴范围和刻度
all_values = []
for group in [group1, group2, group3]:
    all_values.extend(group[0])
    all_values.extend(group[1])
y_min, y_max = min(all_values), max(all_values)
y_min = 0  # 从0开始
# y_max = 0.25  # 根据数据适当调整
y_max = y_max * 1.01  # 最大值增加10%的边距
# 确保y_max至少为0.1，避免数据过小的情况
y_max = max(y_max, 0.1)

ax.set_ylim(y_min, y_max)
ax.set_yticks(np.arange(y_min, y_max + 0.05, 0.05))
ax.set_yticklabels([f'{tick:.2f}' for tick in np.arange(y_min, y_max + 0.05, 0.05)])

# 创建自定义图例
legend_elements = [
    # Patch(facecolor='none', edgecolor='black', linewidth=thin_linewidth, label='Box'),
    # Line2D([0], [0], color='red', linewidth=thin_linewidth, label='Median'),
    # Line2D([0], [0], marker='o', color='w', markerfacecolor='green',
    #        markeredgecolor='green', markersize=4,
    #        markeredgewidth=thin_linewidth / 2, label='Mean'),

    # Patch(facecolor='#FF0000', alpha=0.2, label='Q_UDL'),  # 红色
    # Patch(facecolor='#0066CC', alpha=0.2, label='S_UDL'),  # 蓝色
    # Patch(facecolor='#009900', alpha=0.2, label='Z_UDL')  # 绿色

    Patch(facecolor='#FF0000', alpha=0.2, label='Q_EEQ'),  # 红色
    Patch(facecolor='#0066CC', alpha=0.2, label='S_EEQ'),  # 蓝色
    Patch(facecolor='#009900', alpha=0.2, label='Z_EEQ')  # 绿色
]
ax.legend(handles=legend_elements, loc='upper right', fontsize=16)

# 添加分组指示线
for i in range((num_columns-1)):
    ax.axvline(x=(i + 1) * 4 + 0.5, color='gray', linestyle='--', linewidth=0.5, alpha=0.3)

# # 添加统计信息文本框
# stats_text = f"""Statistics Summary:
# Group 1 Mean: {np.mean(group1[0] + group1[1]):.4f}
# Group 2 Mean: {np.mean(group2[0] + group2[1]):.4f}
# Group 3 Mean: {np.mean(group3[0] + group3[1]):.4f}"""

# ax.text(0.02, 0.98, stats_text, transform=ax.transAxes, fontsize=9,
#         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# 调整布局
plt.tight_layout()


# 保存图片
plt.savefig('three_groups_boxplot_fixed_EEQ.png', dpi=300, bbox_inches='tight')
print("Boxplot saved as 'three_groups_boxplot_fixed_EEQ.png'")

# 显示图形
plt.show()

# 输出数据统计信息
print("\n=== 数据统计信息 ===")
print(f"Group 1: 平均值 = {np.mean(group1[0] + group1[1]):.4f}, 标准差 = {np.std(group1[0] + group1[1]):.4f}")
print(f"Group 2: 平均值 = {np.mean(group2[0] + group2[1]):.4f}, 标准差 = {np.std(group2[0] + group2[1]):.4f}")
print(f"Group 3: 平均值 = {np.mean(group3[0] + group3[1]):.4f}, 标准差 = {np.std(group3[0] + group3[1]):.4f}")