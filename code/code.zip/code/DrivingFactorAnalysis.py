# # -*- coding: utf-8 -*-
# import os
# import warnings
# warnings.filterwarnings("ignore")
#
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
#
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.preprocessing import StandardScaler
# from sklearn.inspection import permutation_importance
#
#
# # =========================
# # User config
# # =========================
# INPUT_XLSX = "驱动因素输入V2.xlsx"  # ← 改成你的文件名
# OUT_DIR = "RF_DrivingFactor_Results"
# SAVE_EXCEL_SUMMARY = True  # 是否汇总保存一个总Excel
# MIN_TRAIN_SIZE = 4         # forward-chaining最小训练年份数
# N_SEED_REPEATS = 10        # 外层seed重复次数（稳定性）
# N_PERM_REPEATS = 10       # permutation内部重复次数
# RF_N_ESTIMATORS = 50
# RF_MAX_DEPTH = 2
#
# # 指标分组（按你要求）
# UDL_FEATURES = [f"X{i}" for i in range(1, 11)]      # X1-X10
# EEQ_FEATURES = [f"X{i}" for i in range(11, 23)]     # X11-X22
# TARGET_COL = "CCD"
#
#
# # =========================
# # 1) Data loader (sheet -> year-row dataframe)
# # =========================
# def load_city_sheet_as_year_rows(xlsx_path: str, sheet_name: str) -> pd.DataFrame:
#     """
#     读取单个城市sheet：
#     - 期望格式：行=指标（X1..X22, CCD），列=年份（2014..2023..）
#     - 返回格式：行=年份，列=特征（X1..X22）+ CCD
#     """
#     raw = pd.read_excel(xlsx_path, sheet_name=sheet_name, index_col=0)
#     raw.index = raw.index.astype(str).str.strip()
#
#     # 去掉可能的空列/空行
#     raw = raw.dropna(axis=0, how="all").dropna(axis=1, how="all")
#
#     # 列名年份转为int（若可以）
#     years = []
#     for c in raw.columns:
#         try:
#             years.append(int(str(c).strip()))
#         except Exception:
#             years.append(str(c).strip())
#     raw.columns = years
#
#     # 防止出现0
#     raw = raw.replace(0.0, 1e-7).clip(lower=1e-7)
#
#     # 检查必须存在的行
#     required_rows = set(UDL_FEATURES + EEQ_FEATURES + [TARGET_COL])
#     missing = [r for r in required_rows if r not in raw.index]
#     if missing:
#         raise ValueError(f"[{sheet_name}] 缺失行指标: {missing}。请检查sheet的行名是否为 X1..X22 与 CCD。")
#
#     # 只取需要的指标，转为 years x features
#     raw_use = raw.loc[UDL_FEATURES + EEQ_FEATURES + [TARGET_COL], :].astype(float)
#     df_year = raw_use.T  # index=year, columns=X1..X22, CCD
#     df_year.index.name = "Year"
#
#     # 年份排序（如果是int）
#     try:
#         df_year = df_year.sort_index()
#     except Exception:
#         pass
#
#     return df_year
#
#
# # # =========================
# # # 2) Time-aware RF + permutation importance (core)
# # # =========================
# # def rf_timeaware_perm_importance(
# #     df_year: pd.DataFrame,
# #     feature_list: list,
# #     target_col: str,
# #     group_name: str,
# #     min_train_size: int = 4,
# #     n_seed_repeats: int = 10,
# #     n_perm_repeats: int = 10,
# #     rf_n_estimators: int = 30,
# #     rf_max_depth: int = 2,
# #     scoring: str = "neg_mean_squared_error",
# # ):
# #     """
# #     forward-chaining CV + permutation importance:
# #       - folds: train years [0..t], test year [t+1], t from min_train_size-1 to n-2
# #       - repeated across random seeds
# #       - output importance mean/std across all (seed, fold)
# #     """
# #     X_all = df_year[feature_list].copy()
# #     y_all = df_year[target_col].copy()
# #
# #     n = len(df_year)
# #     p = len(feature_list)
# #     if n < min_train_size + 1:
# #         raise ValueError(f"{group_name}: n={n} too small for min_train_size={min_train_size} (need >= {min_train_size+1}).")
# #
# #     # forward-chaining folds
# #     folds = []
# #     for t in range(min_train_size - 1, n - 1):
# #         train_idx = list(range(0, t + 1))
# #         test_idx = [t + 1]
# #         folds.append((train_idx, test_idx))
# #
# #     all_imps = []
# #
# #     for seed in range(n_seed_repeats):
# #         for train_idx, test_idx in folds:
# #             X_train = X_all.iloc[train_idx].values
# #             X_test = X_all.iloc[test_idx].values
# #             y_train = y_all.iloc[train_idx].values
# #             y_test = y_all.iloc[test_idx].values
# #
# #             # standardize (fit on train only)
# #             scaler = StandardScaler()
# #             X_train_s = scaler.fit_transform(X_train)
# #             X_test_s = scaler.transform(X_test)
# #
# #             rf = RandomForestRegressor(
# #                 n_estimators=rf_n_estimators,
# #                 max_depth=rf_max_depth,
# #                 random_state=seed,
# #                 n_jobs=1
# #             )
# #             rf.fit(X_train_s, y_train)
# #
# #             perm = permutation_importance(
# #                 rf,
# #                 X_test_s,
# #                 y_test,
# #                 n_repeats=n_perm_repeats,
# #                 random_state=seed,
# #                 scoring=scoring
# #             )
# #
# #             imp = perm.importances_mean  # (p,)
# #             all_imps.append(imp)
# #
# #     all_imps = np.array(all_imps)  # (runs, p)
# #     mean_imp = all_imps.mean(axis=0)
# #     std_imp = all_imps.std(axis=0)
# #
# #     return {
# #         "features": feature_list,
# #         "avg_importance": mean_imp,
# #         "std_importance": std_imp,
# #         "group": group_name
# #     }
# def rf_timeaware_perm_importance(
#     df_year: pd.DataFrame,
#     feature_list: list,
#     target_col: str,
#     group_name: str,
#     min_train_size: int = 4,
#     n_seed_repeats: int = 10,
#     n_perm_repeats: int = 10,
#     rf_n_estimators: int = 50,
#     rf_max_depth: int = 2,
#     scoring: str = "neg_mean_squared_error",
# ):
#     """
#     Two-stage, time-aware forward-chaining CV importance.
#
#     Fix: permutation importance requires >=2 test samples. We therefore use a
#     forward test window (horizon) internally to guarantee test set size >=2.
#
#     Interface unchanged. Returns:
#       dict {features, avg_importance, std_importance, group}
#     """
#
#     X_all = df_year[feature_list].copy()
#     y_all = df_year[target_col].copy()
#
#     n = len(df_year)
#     p = len(feature_list)
#
#     if n < min_train_size + 1:
#         raise ValueError(
#             f"{group_name}: n={n} too small for min_train_size={min_train_size} "
#             f"(need >= {min_train_size+1})."
#         )
#
#     # ----------------------------
#     # Internal: test window horizon
#     # ----------------------------
#     # Ensure permutation works: test size >= 2 if possible
#     # For n=10, horizon=2 works well; for larger n you can set 3.
#     test_horizon = 2
#     if n - min_train_size < 2:
#         # impossible to have >=2 test samples; fallback will be MDI-only later
#         test_horizon = 1
#
#     # forward-chaining folds with multi-year test window
#     folds = []
#     for t in range(min_train_size - 1, n - 1):
#         test_start = t + 1
#         test_end = min(n, test_start + test_horizon)
#         test_idx = list(range(test_start, test_end))
#         if len(test_idx) == 0:
#             continue
#         folds.append((list(range(0, t + 1)), test_idx))
#
#     if len(folds) == 0:
#         raise RuntimeError(f"{group_name}: no valid folds constructed.")
#
#     # ---------- Two-stage config (internal; interface unchanged) ----------
#     if p <= 6:
#         top_k = p
#     elif p <= 12:
#         top_k = 6
#     else:
#         top_k = 8
#     # --------------------------------------------------------------------
#
#     all_imps = []  # each run returns (p,)
#
#     for seed in range(n_seed_repeats):
#         for train_idx, test_idx in folds:
#             X_train = X_all.iloc[train_idx].values
#             X_test  = X_all.iloc[test_idx].values
#             y_train = y_all.iloc[train_idx].values
#             y_test  = y_all.iloc[test_idx].values
#
#             scaler = StandardScaler()
#             X_train_s = scaler.fit_transform(X_train)
#             X_test_s  = scaler.transform(X_test)
#
#             rf = RandomForestRegressor(
#                 n_estimators=rf_n_estimators,
#                 max_depth=rf_max_depth,
#                 random_state=seed,
#                 n_jobs=1
#             )
#             rf.fit(X_train_s, y_train)
#
#             # =========================
#             # Stage-1: MDI screen
#             # =========================
#             mdi = getattr(rf, "feature_importances_", None)
#             if mdi is None or len(mdi) != p or (mdi.sum() <= 0):
#                 top_idx = np.arange(p)
#             else:
#                 top_idx = np.argsort(mdi)[::-1][:top_k]
#
#             run_imp = np.zeros(p, dtype=float)
#
#             # =========================
#             # Stage-2: Permutation on Top-K
#             # =========================
#             # If test set has only 1 sample, permutation is meaningless.
#             # In that rare case, fall back to MDI values (scaled to keep non-negative).
#             if len(test_idx) < 2:
#                 # fallback to MDI for this run
#                 run_imp[top_idx] = np.maximum(mdi[top_idx], 0.0)
#                 all_imps.append(run_imp)
#                 continue
#
#             X_train_top = X_train_s[:, top_idx]
#             X_test_top  = X_test_s[:, top_idx]
#
#             rf_top = RandomForestRegressor(
#                 n_estimators=rf_n_estimators,
#                 max_depth=rf_max_depth,
#                 random_state=seed,
#                 n_jobs=1
#             )
#             rf_top.fit(X_train_top, y_train)
#
#             perm = permutation_importance(
#                 rf_top,
#                 X_test_top,
#                 y_test,
#                 n_repeats=n_perm_repeats,
#                 random_state=seed,
#                 scoring=scoring
#             )
#             perm_imp = perm.importances_mean
#
#             # map back
#             run_imp[top_idx] = perm_imp
#             all_imps.append(run_imp)
#
#     all_imps = np.array(all_imps)  # (runs, p)
#     mean_imp = all_imps.mean(axis=0)
#     std_imp  = all_imps.std(axis=0)
#
#     # Keep finite
#     mean_imp = np.nan_to_num(mean_imp, nan=0.0, posinf=0.0, neginf=0.0)
#     std_imp  = np.nan_to_num(std_imp,  nan=0.0, posinf=0.0, neginf=0.0)
#
#     return {
#         "features": feature_list,
#         "avg_importance": mean_imp,
#         "std_importance": std_imp,
#         "group": group_name
#     }
#
# def create_importance_df(results: dict) -> pd.DataFrame:
#     out = pd.DataFrame({
#         "Feature": results["features"],
#         "Mean_Importance": results["avg_importance"],
#         "Std_Importance": results["std_importance"]
#     }).sort_values("Mean_Importance", ascending=False)
#     out["Rank"] = range(1, len(out) + 1)
#     out["Cumulative_Importance"] = out["Mean_Importance"].cumsum()
#     return out
#
#
# # =========================
# # 3) Plotting per city
# # =========================
# # def plot_city_results_sci(
# #     city_name: str,
# #     df_year,
# #     all_df,
# #     udl_df,
# #     eeq_df,
# #     out_png: str,
# #     topk_all: int = 10,
# #     topk_group: int = 10,
# #     dpi: int = 600,
# #     show: bool = False,
# #     english: bool = True,
# # ):
# #     """
# #     SCI-style figure:
# #       (a) Top drivers (All)  barh
# #       (b) UDL drivers        barh
# #       (c) EEQ drivers        barh
# #       (d) CCD time series
# #       (e) Cumulative importance curves (All/UDL/EEQ)  [normalized cumulative contribution ratio]
# #
# #     Notes:
# #     - No change to analysis, only visualization.
# #     - Bright, publication-ready palette.
# #     """
# #     import numpy as np
# #     import matplotlib.pyplot as plt
# #
# #     # --------- Style (paper-ready) ----------
# #     plt.rcParams.update({
# #         "font.family": "DejaVu Sans",   # 中文可改为 "SimHei" 或系统可用中文字体
# #         "font.size": 11,
# #         "axes.titlesize": 12,
# #         "axes.labelsize": 11,
# #         "xtick.labelsize": 10,
# #         "ytick.labelsize": 10,
# #         "legend.fontsize": 9,
# #         "axes.linewidth": 1.0,
# #         "figure.dpi": 120,
# #     })
# #
# #     # Bright palette (color-blind friendly)
# #     C_ALL = "#0072B2"   # blue
# #     C_UDL = "#E69F00"   # orange
# #     C_EEQ = "#009E73"   # green
# #     C_CCD = "#D55E00"   # vermillion
# #     GRID = "#D0D0D0"
# #
# #     years = df_year.index.tolist()
# #     ccd = df_year["CCD"].values
# #
# #     # --------- Prepare data ----------
# #     def prep_top(df_imp, k):
# #         d = df_imp.copy().head(k)
# #         d = d.iloc[::-1]  # reverse for barh
# #         return d
# #
# #     top_all = prep_top(all_df, topk_all)
# #     top_udl = prep_top(udl_df, min(topk_group, len(udl_df)))
# #     top_eeq = prep_top(eeq_df, min(topk_group, len(eeq_df)))
# #
# #     # Avoid negative bars for display (keep original in tables)
# #     top_all_vals = np.clip(top_all["Mean_Importance"].values, 0, None)
# #     top_udl_vals = np.clip(top_udl["Mean_Importance"].values, 0, None)
# #     top_eeq_vals = np.clip(top_eeq["Mean_Importance"].values, 0, None)
# #
# #     # Global x-limit to make bar charts comparable
# #     xmax = max(top_all_vals.max(initial=0), top_udl_vals.max(initial=0), top_eeq_vals.max(initial=0))
# #     xmax = xmax * 1.12 if xmax > 0 else 1.0
# #
# #     # --------- Layout ----------
# #     fig = plt.figure(figsize=(14.5, 8.5))
# #     gs = fig.add_gridspec(
# #         2, 3,
# #         width_ratios=[1.05, 1.05, 1.1],
# #         height_ratios=[1, 1],
# #         wspace=0.28, hspace=0.32
# #     )
# #
# #     ax1 = fig.add_subplot(gs[0, 0])   # All
# #     ax2 = fig.add_subplot(gs[0, 1])   # UDL
# #     ax3 = fig.add_subplot(gs[1, 0])   # EEQ
# #     ax4 = fig.add_subplot(gs[0, 2])   # CCD
# #     ax5 = fig.add_subplot(gs[1, 2])   # Cumulative
# #
# #     # --------- Titles ----------
# #     if english:
# #         t1 = f"{city_name}: Top-{topk_all} Drivers (All Indicators)"
# #         t2 = f"{city_name}: UDL Drivers (X1–X10)"
# #         t3 = f"{city_name}: EEQ Drivers (X11–X22)"
# #         t4 = f"{city_name}: CCD Time Series"
# #         t5 = f"{city_name}: Cumulative Contribution"
# #         xlab = "Permutation Importance (mean)"
# #         ylab_cum = "Cumulative Contribution Ratio"
# #     else:
# #         t1 = f"{city_name}：综合 Top-{topk_all} 驱动因子（全指标）"
# #         t2 = f"{city_name}：UDL 驱动因子（X1–X10）"
# #         t3 = f"{city_name}：EEQ 驱动因子（X11–X22）"
# #         t4 = f"{city_name}：CCD 年际变化"
# #         t5 = f"{city_name}：累计贡献率"
# #         xlab = "Permutation Importance（均值）"
# #         ylab_cum = "累计贡献率"
# #
# #     # --------- Helper: barh ----------
# #     def barh_plot(ax, df_top, vals, color, title):
# #         ax.barh(df_top["Feature"].values, vals, color=color, alpha=0.95, edgecolor="none")
# #         ax.set_title(title, pad=8)
# #         ax.set_xlabel(xlab)
# #         ax.set_xlim(0, xmax)
# #         ax.grid(axis="x", color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
# #         ax.grid(axis="y", visible=False)
# #         for spine in ["top", "right"]:
# #             ax.spines[spine].set_visible(False)
# #
# #     barh_plot(ax1, top_all, top_all_vals, C_ALL, t1)
# #     barh_plot(ax2, top_udl, top_udl_vals, C_UDL, t2)
# #     barh_plot(ax3, top_eeq, top_eeq_vals, C_EEQ, t3)
# #
# #     # --------- (d) CCD time series ----------
# #     ax4.plot(years, ccd, marker="o", linewidth=2.2, color=C_CCD, label="CCD")
# #     ax4.set_title(t4, pad=8)
# #     ax4.set_xlabel("Year")
# #     ax4.set_ylabel("CCD")
# #     ax4.grid(color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
# #     ax4.set_xticks(years)
# #     ax4.tick_params(axis="x", rotation=35)
# #     for spine in ["top", "right"]:
# #         ax4.spines[spine].set_visible(False)
# #     ax4.legend(loc="best", frameon=True)
# #
# #     # --------- (e) cumulative contribution curves (FIXED) ----------
# #     # IMPORTANT:
# #     # Permutation importance does NOT sum to 1, so cumsum(importance) is not a "percentage".
# #     # Normalize to get cumulative contribution ratio in [0,1], then 80% threshold is meaningful.
# #     def cum_ratio(df_imp):
# #         imp = np.clip(df_imp["Mean_Importance"].values, 0, None)  # only positive contribution
# #         s = imp.sum()
# #         if s <= 0:
# #             return np.zeros_like(imp)
# #         return np.cumsum(imp) / s
# #
# #     cum_all = cum_ratio(all_df)
# #     cum_udl = cum_ratio(udl_df)
# #     cum_eeq = cum_ratio(eeq_df)
# #
# #     x_all = np.arange(1, len(cum_all) + 1)
# #     x_udl = np.arange(1, len(cum_udl) + 1)
# #     x_eeq = np.arange(1, len(cum_eeq) + 1)
# #
# #     ax5.plot(x_all, cum_all, marker="o", linewidth=2.0, color=C_ALL, label="All")
# #     ax5.plot(x_udl, cum_udl, marker="s", linewidth=2.0, color=C_UDL, label="UDL")
# #     ax5.plot(x_eeq, cum_eeq, marker="^", linewidth=2.0, color=C_EEQ, label="EEQ")
# #
# #     ax5.axhline(0.8, color="#CC79A7", linestyle="--", linewidth=1.6, label="80%")
# #     ax5.set_title(t5, pad=8)
# #     ax5.set_xlabel("Number of Features")
# #     ax5.set_ylabel(ylab_cum)
# #
# #     # axis ranges
# #     ax5.set_ylim(0, 1.02)
# #     max_len = max(len(cum_all), len(cum_udl), len(cum_eeq))
# #     ax5.set_xlim(1, max_len + 0.5)
# #
# #     ax5.grid(color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
# #     for spine in ["top", "right"]:
# #         ax5.spines[spine].set_visible(False)
# #
# #     # Legend outside to avoid blocking curves; works well for narrow subplot
# #     ax5.legend(
# #         loc="upper center",
# #         bbox_to_anchor=(0.5, -0.18),
# #         ncol=4,
# #         frameon=True
# #     )
# #
# #     # --------- Save / show ----------
# #     plt.savefig(out_png, dpi=dpi, bbox_inches="tight")
# #     if show:
# #         plt.show()
# #     plt.close(fig)
#
# def plot_city_results_sci(
#     city_name: str,
#     df_year,
#     all_df,
#     udl_df,
#     eeq_df,
#     out_png: str | None = None,
#     topk_all: int = 10,
#     topk_group: int = 10,
#     dpi: int = 600,
#     show: bool = False,
#     english: bool = True,
#     axes_row=None,                 # 外部 5 axes（用于7×5总图）
#     set_col_titles: bool = False,  # 只在第一行写列标题
#     xmax_global: float | None = None,          # ✅ 新增：全局条形图上限
#     ccd_ylim_global: tuple[float, float] | None = None,  # ✅ 新增：全局CCD y轴范围
# ):
#     """
#     If axes_row is None: standalone single-city figure (old behavior).
#     If axes_row is provided (len=5): draw in given axes row for a global grid.
#
#     Columns:
#       0=All barh, 1=UDL barh, 2=EEQ barh, 3=CCD, 4=Cumulative (normalized)
#     """
#
#     # --------- Style ----------
#     plt.rcParams.update({
#         "font.family": "DejaVu Sans",
#         "font.size": 10,
#         "axes.titlesize": 11,
#         "axes.labelsize": 10,
#         "xtick.labelsize": 9,
#         "ytick.labelsize": 9,
#         "legend.fontsize": 8,
#         "axes.linewidth": 1.0,
#     })
#
#     # Bright palette (Okabe-Ito)
#     C_ALL = "#0072B2"
#     C_UDL = "#E69F00"
#     C_EEQ = "#009E73"
#     C_CCD = "#D55E00"
#     C_80  = "#CC79A7"
#     GRID = "#D0D0D0"
#
#     years = df_year.index.tolist()
#     ccd = df_year["CCD"].values
#
#     # --------- Prepare top-k ----------
#     def prep_top(df_imp, k):
#         d = df_imp.copy().head(k)
#         return d.iloc[::-1]
#
#     top_all = prep_top(all_df, topk_all)
#     top_udl = prep_top(udl_df, min(topk_group, len(udl_df)))
#     top_eeq = prep_top(eeq_df, min(topk_group, len(eeq_df)))
#
#     top_all_vals = np.clip(top_all["Mean_Importance"].values, 0, None)
#     top_udl_vals = np.clip(top_udl["Mean_Importance"].values, 0, None)
#     top_eeq_vals = np.clip(top_eeq["Mean_Importance"].values, 0, None)
#
#     xmax_local = max(top_all_vals.max(initial=0), top_udl_vals.max(initial=0), top_eeq_vals.max(initial=0))
#     xmax_local = xmax_local * 1.12 if xmax_local > 0 else 1.0
#     xmax = float(xmax_global) if xmax_global is not None else xmax_local
#
#     # --------- Titles ----------
#     if english:
#         col_titles = [
#             f"Top-{topk_all} Drivers (All)",
#             "UDL Drivers (X1–X10)",
#             "EEQ Drivers (X11–X22)",
#             "CCD Time Series",
#             "Cumulative Contribution",
#         ]
#         xlab = "Permutation Importance (mean)"
#         ylab_cum = "Cum. Contribution"
#     else:
#         col_titles = [
#             f"综合 Top-{topk_all} 驱动因子（全指标）",
#             "UDL 驱动因子（X1–X10）",
#             "EEQ 驱动因子（X11–X22）",
#             "CCD 年际变化",
#             "累计贡献率",
#         ]
#         xlab = "Permutation Importance（均值）"
#         ylab_cum = "累计贡献率"
#
#     # --------- Axes selection ----------
#     if axes_row is None:
#         fig = plt.figure(figsize=(14.5, 8.5))
#         gs = fig.add_gridspec(2, 3, width_ratios=[1.05, 1.05, 1.1], height_ratios=[1, 1],
#                               wspace=0.28, hspace=0.32)
#         ax_all = fig.add_subplot(gs[0, 0])
#         ax_udl = fig.add_subplot(gs[0, 1])
#         ax_eeq = fig.add_subplot(gs[1, 0])
#         ax_ccd = fig.add_subplot(gs[0, 2])
#         ax_cum = fig.add_subplot(gs[1, 2])
#         created_fig = True
#     else:
#         ax_all, ax_udl, ax_eeq, ax_ccd, ax_cum = axes_row
#         fig = ax_all.figure
#         created_fig = False
#
#     # --------- Column titles ----------
#     if set_col_titles:
#         ax_all.set_title(col_titles[0], pad=6)
#         ax_udl.set_title(col_titles[1], pad=6)
#         ax_eeq.set_title(col_titles[2], pad=6)
#         ax_ccd.set_title(col_titles[3], pad=6)
#         ax_cum.set_title(col_titles[4], pad=6)
#     elif created_fig:
#         ax_all.set_title(f"{city_name}: {col_titles[0]}", pad=6)
#         ax_udl.set_title(f"{city_name}: {col_titles[1]}", pad=6)
#         ax_eeq.set_title(f"{city_name}: {col_titles[2]}", pad=6)
#         ax_ccd.set_title(f"{city_name}: {col_titles[3]}", pad=6)
#         ax_cum.set_title(f"{city_name}: {col_titles[4]}", pad=6)
#
#     # --------- barh helper ----------
#     def barh_plot(ax, df_top, vals, color, show_xlabel: bool, show_ylabel: bool):
#         ax.barh(df_top["Feature"].values, vals, color=color, alpha=0.95, edgecolor="none")
#         ax.set_xlim(0, xmax)
#         ax.grid(axis="x", color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
#         ax.grid(axis="y", visible=False)
#         for spine in ["top", "right"]:
#             ax.spines[spine].set_visible(False)
#         ax.set_xlabel(xlab if show_xlabel else "")
#         if not show_ylabel:
#             ax.set_ylabel("")
#
#     show_xlabel = created_fig
#     barh_plot(ax_all, top_all, top_all_vals, C_ALL, show_xlabel, True)
#     barh_plot(ax_udl, top_udl, top_udl_vals, C_UDL, show_xlabel, False)
#     barh_plot(ax_eeq, top_eeq, top_eeq_vals, C_EEQ, show_xlabel, True)
#
#     # 城市名（总图每行左侧）
#     if not created_fig:
#         ax_all.set_ylabel(city_name, fontsize=11, rotation=0, labelpad=40, va="center")
#
#     # --------- CCD time series ----------
#     ax_ccd.plot(years, ccd, marker="o", linewidth=2.0, color=C_CCD, label="CCD")
#     ax_ccd.grid(color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
#     ax_ccd.set_xticks(years)
#     ax_ccd.tick_params(axis="x", rotation=35)
#     for spine in ["top", "right"]:
#         ax_ccd.spines[spine].set_visible(False)
#
#     # ✅ 统一CCD y轴范围
#     if ccd_ylim_global is not None:
#         ax_ccd.set_ylim(ccd_ylim_global)
#
#     if created_fig:
#         ax_ccd.set_xlabel("Year")
#         ax_ccd.set_ylabel("CCD")
#         ax_ccd.legend(loc="best", frameon=True)
#     else:
#         ax_ccd.set_xlabel("")
#         ax_ccd.set_ylabel("")
#         ax_ccd.legend(loc="upper left", frameon=True)
#
#     # --------- cumulative contribution (normalized) ----------
#     def cum_ratio(df_imp):
#         imp = np.clip(df_imp["Mean_Importance"].values, 0, None)
#         s = imp.sum()
#         if s <= 0:
#             return np.zeros_like(imp)
#         return np.cumsum(imp) / s
#
#     cum_all = cum_ratio(all_df)
#     cum_udl = cum_ratio(udl_df)
#     cum_eeq = cum_ratio(eeq_df)
#
#     ax_cum.plot(range(1, len(cum_all) + 1), cum_all, marker="o", linewidth=1.8, color=C_ALL, label="All")
#     ax_cum.plot(range(1, len(cum_udl) + 1), cum_udl, marker="s", linewidth=1.8, color=C_UDL, label="UDL")
#     ax_cum.plot(range(1, len(cum_eeq) + 1), cum_eeq, marker="^", linewidth=1.8, color=C_EEQ, label="EEQ")
#     ax_cum.axhline(0.8, color=C_80, linestyle="--", linewidth=1.3, label="80%")
#
#     ax_cum.set_ylim(0, 1.02)
#     max_len = max(len(cum_all), len(cum_udl), len(cum_eeq))
#     ax_cum.set_xlim(1, max_len + 0.5)
#     ax_cum.grid(color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
#     for spine in ["top", "right"]:
#         ax_cum.spines[spine].set_visible(False)
#
#     if created_fig:
#         ax_cum.set_xlabel("Number of Features")
#         ax_cum.set_ylabel(ylab_cum)
#         ax_cum.legend(loc="lower right", frameon=True)
#     else:
#         ax_cum.set_xlabel("")
#         ax_cum.set_ylabel("")
#         # 总图不在子图内放legend（用全局legend）
#         if ax_cum.get_legend() is not None:
#             ax_cum.get_legend().remove()
#
#     # --------- Save / show ----------
#     if created_fig and out_png:
#         plt.savefig(out_png, dpi=dpi, bbox_inches="tight")
#         if show:
#             plt.show()
#         plt.close(fig)
#
# # =========================
# # 4) Run all cities
# # =========================
# def run_all_cities(xlsx_path: str, out_dir: str):
#     os.makedirs(out_dir, exist_ok=True)
#
#     xls = pd.ExcelFile(xlsx_path)
#     sheet_names = xls.sheet_names  # 默认全部sheet都是城市
#
#     summary_rows = []  # 汇总top drivers
#
#     excel_writer = None
#     if SAVE_EXCEL_SUMMARY:
#         excel_writer = pd.ExcelWriter(os.path.join(out_dir, "RF_Importance_AllCities.xlsx"))
#
#     for city in sheet_names:
#         print(f"\n=== Processing city: {city} ===")
#         df_year = load_city_sheet_as_year_rows(xlsx_path, city)
#
#         # basic sanity check
#         for col in UDL_FEATURES + EEQ_FEATURES + [TARGET_COL]:
#             if col not in df_year.columns:
#                 raise ValueError(f"[{city}] 缺失列: {col}。")
#
#         # Run 3 analyses
#         all_features = UDL_FEATURES + EEQ_FEATURES
#
#         all_results = rf_timeaware_perm_importance(
#             df_year=df_year, feature_list=all_features, target_col=TARGET_COL,
#             group_name="All",
#             min_train_size=MIN_TRAIN_SIZE,
#             n_seed_repeats=N_SEED_REPEATS,
#             n_perm_repeats=N_PERM_REPEATS,
#             rf_n_estimators=RF_N_ESTIMATORS,
#             rf_max_depth=RF_MAX_DEPTH
#         )
#         udl_results = rf_timeaware_perm_importance(
#             df_year=df_year, feature_list=UDL_FEATURES, target_col=TARGET_COL,
#             group_name="UDL",
#             min_train_size=MIN_TRAIN_SIZE,
#             n_seed_repeats=N_SEED_REPEATS,
#             n_perm_repeats=N_PERM_REPEATS,
#             rf_n_estimators=RF_N_ESTIMATORS,
#             rf_max_depth=RF_MAX_DEPTH
#         )
#         eeq_results = rf_timeaware_perm_importance(
#             df_year=df_year, feature_list=EEQ_FEATURES, target_col=TARGET_COL,
#             group_name="EEQ",
#             min_train_size=MIN_TRAIN_SIZE,
#             n_seed_repeats=N_SEED_REPEATS,
#             n_perm_repeats=N_PERM_REPEATS,
#             rf_n_estimators=RF_N_ESTIMATORS,
#             rf_max_depth=RF_MAX_DEPTH
#         )
#
#         all_df = create_importance_df(all_results)
#         udl_df = create_importance_df(udl_results)
#         eeq_df = create_importance_df(eeq_results)
#
#         # Save CSVs
#         city_safe = str(city).replace("/", "_").replace("\\", "_")
#         all_df.to_csv(os.path.join(out_dir, f"{city_safe}_All_Importance.csv"), index=False)
#         udl_df.to_csv(os.path.join(out_dir, f"{city_safe}_UDL_Importance.csv"), index=False)
#         eeq_df.to_csv(os.path.join(out_dir, f"{city_safe}_EEQ_Importance.csv"), index=False)
#
#         # Save to one Excel (optional)
#         if excel_writer is not None:
#             all_df.to_excel(excel_writer, sheet_name=f"{city_safe}_All", index=False)
#             udl_df.to_excel(excel_writer, sheet_name=f"{city_safe}_UDL", index=False)
#             eeq_df.to_excel(excel_writer, sheet_name=f"{city_safe}_EEQ", index=False)
#
#         # Plot & save figure
#         out_png = os.path.join(out_dir, f"{city_safe}_RF_Drivers.png")
#         plot_city_results_sci(
#             city_name=city_safe,
#             df_year=df_year,
#             all_df=all_df,
#             udl_df=udl_df,
#             eeq_df=eeq_df,
#             out_png=out_png,
#             topk_all=10,
#             topk_group=10,
#             dpi=600,
#             show=False,  # 批处理建议False
#             english=True  # SCI论文建议英文
#         )
#
#         city_results = []
#         for city_name in sheet_names:
#             # ...你已有的读取 + 分析...
#             city_results.append({
#                 "city": city_name,
#                 "df_year": df_year,
#                 "all_df": all_df,
#                 "udl_df": udl_df,
#                 "eeq_df": eeq_df
#             })
#
#         plot_all_cities_grid_7x5(
#             city_results,
#             out_png="AllCities_7x5_RFDrivers.png",
#             dpi=600,
#             english=True,
#             topk_all=10,
#             topk_group=10
#         )
#
#         # Collect summary (top-3 each)
#         def topk(df_imp, k=3):
#             return [(r["Feature"], r["Mean_Importance"], r["Std_Importance"]) for _, r in df_imp.head(k).iterrows()]
#
#         for grp, df_imp in [("All", all_df), ("UDL", udl_df), ("EEQ", eeq_df)]:
#             for rank, (feat, mean_i, std_i) in enumerate(topk(df_imp, 3), start=1):
#                 summary_rows.append({
#                     "City": city_safe,
#                     "Group": grp,
#                     "Rank": rank,
#                     "Feature": feat,
#                     "Mean_Importance": float(mean_i),
#                     "Std_Importance": float(std_i)
#                 })
#
#     if excel_writer is not None:
#         excel_writer.close()
#
#     summary_df = pd.DataFrame(summary_rows)
#     summary_df.to_csv(os.path.join(out_dir, "AllCities_TopDrivers_Summary.csv"), index=False)
#     print(f"\n✓ Done. Results saved to: {out_dir}")
#     print("  - Per-city CSVs + figures")
#     print("  - AllCities_TopDrivers_Summary.csv")
#     if SAVE_EXCEL_SUMMARY:
#         print("  - RF_Importance_AllCities.xlsx")
#
#
# if __name__ == "__main__":
#     run_all_cities(INPUT_XLSX, OUT_DIR)

# -*- coding: utf-8 -*-

#*************************************************************************************#

# import os
# import warnings
# warnings.filterwarnings("ignore")
#
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
#
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.preprocessing import StandardScaler
# from sklearn.inspection import permutation_importance
#
#
# # =========================
# # User config
# # =========================
# INPUT_XLSX = "驱动因素输入V2.xlsx"  # ← 改成你的文件名
# OUT_DIR = "RF_DrivingFactor_Results"
# SAVE_EXCEL_SUMMARY = True  # 是否汇总保存一个总Excel
# SAVE_PER_CITY_FIG = True   # 是否每个城市也保存单独图（可关掉加速）
# MIN_TRAIN_SIZE = 4         # forward-chaining最小训练年份数
# N_SEED_REPEATS = 10        # 外层seed重复次数（稳定性）
# N_PERM_REPEATS = 10        # permutation内部重复次数
# RF_N_ESTIMATORS = 50
# RF_MAX_DEPTH = 2
#
# # 指标分组
# UDL_FEATURES = [f"X{i}" for i in range(1, 11)]      # X1-X10
# EEQ_FEATURES = [f"X{i}" for i in range(11, 23)]     # X11-X22
# TARGET_COL = "CCD"
#
#
# # =========================
# # 1) Data loader (sheet -> year-row dataframe)
# # =========================
# def load_city_sheet_as_year_rows(xlsx_path: str, sheet_name: str) -> pd.DataFrame:
#     """
#     读取单个城市sheet：
#     - 期望格式：行=指标（X1..X22, CCD），列=年份（2014..2023..）
#     - 返回格式：行=年份，列=特征（X1..X22）+ CCD
#     """
#     raw = pd.read_excel(xlsx_path, sheet_name=sheet_name, index_col=0)
#     raw.index = raw.index.astype(str).str.strip()
#
#     # 去掉可能的空列/空行
#     raw = raw.dropna(axis=0, how="all").dropna(axis=1, how="all")
#
#     # 列名年份转为int（若可以）
#     years = []
#     for c in raw.columns:
#         try:
#             years.append(int(str(c).strip()))
#         except Exception:
#             years.append(str(c).strip())
#     raw.columns = years
#
#     # 防止出现0（避免后续log/除法/绘图中出现0导致的奇异）
#     raw = raw.replace(0.0, 1e-7).clip(lower=1e-7)
#
#     # 检查必须存在的行
#     required_rows = set(UDL_FEATURES + EEQ_FEATURES + [TARGET_COL])
#     missing = [r for r in required_rows if r not in raw.index]
#     if missing:
#         raise ValueError(f"[{sheet_name}] 缺失行指标: {missing}。请检查sheet行名是否为 X1..X22 与 CCD。")
#
#     # 只取需要的指标，转为 years x features
#     raw_use = raw.loc[UDL_FEATURES + EEQ_FEATURES + [TARGET_COL], :].astype(float)
#     df_year = raw_use.T
#     df_year.index.name = "Year"
#
#     # 年份排序（如果是int）
#     try:
#         df_year = df_year.sort_index()
#     except Exception:
#         pass
#
#     return df_year
#
#
# # =========================
# # 2) Time-aware RF + permutation importance (two-stage; interface unchanged)
# # =========================
# def rf_timeaware_perm_importance(
#     df_year: pd.DataFrame,
#     feature_list: list,
#     target_col: str,
#     group_name: str,
#     min_train_size: int = 4,
#     n_seed_repeats: int = 10,
#     n_perm_repeats: int = 10,
#     rf_n_estimators: int = 50,
#     rf_max_depth: int = 2,
#     scoring: str = "neg_mean_squared_error",
# ):
#     """
#     Two-stage, time-aware forward-chaining CV importance.
#
#     Fix: permutation importance requires >=2 test samples. We therefore use a
#     forward test window (horizon) internally to guarantee test set size >=2.
#
#     Interface unchanged. Returns:
#       dict {features, avg_importance, std_importance, group}
#     """
#
#     X_all = df_year[feature_list].copy()
#     y_all = df_year[target_col].copy()
#
#     n = len(df_year)
#     p = len(feature_list)
#
#     if n < min_train_size + 1:
#         raise ValueError(
#             f"{group_name}: n={n} too small for min_train_size={min_train_size} "
#             f"(need >= {min_train_size+1})."
#         )
#
#     # ----------------------------
#     # Internal: test window horizon
#     # ----------------------------
#     test_horizon = 2
#     if n - min_train_size < 2:
#         test_horizon = 1  # fallback
#
#     folds = []
#     for t in range(min_train_size - 1, n - 1):
#         test_start = t + 1
#         test_end = min(n, test_start + test_horizon)
#         test_idx = list(range(test_start, test_end))
#         if len(test_idx) == 0:
#             continue
#         folds.append((list(range(0, t + 1)), test_idx))
#
#     if len(folds) == 0:
#         raise RuntimeError(f"{group_name}: no valid folds constructed.")
#
#     # ---------- Two-stage config (internal) ----------
#     if p <= 6:
#         top_k = p
#     elif p <= 12:
#         top_k = 6
#     else:
#         top_k = 8
#     # -----------------------------------------------
#
#     all_imps = []
#
#     for seed in range(n_seed_repeats):
#         for train_idx, test_idx in folds:
#             X_train = X_all.iloc[train_idx].values
#             X_test  = X_all.iloc[test_idx].values
#             y_train = y_all.iloc[train_idx].values
#             y_test  = y_all.iloc[test_idx].values
#
#             scaler = StandardScaler()
#             X_train_s = scaler.fit_transform(X_train)
#             X_test_s  = scaler.transform(X_test)
#
#             rf = RandomForestRegressor(
#                 n_estimators=rf_n_estimators,
#                 max_depth=rf_max_depth,
#                 random_state=seed,
#                 n_jobs=1
#             )
#             rf.fit(X_train_s, y_train)
#
#             # Stage-1: MDI screen
#             mdi = getattr(rf, "feature_importances_", None)
#             if mdi is None or len(mdi) != p or (mdi.sum() <= 0):
#                 top_idx = np.arange(p)
#             else:
#                 top_idx = np.argsort(mdi)[::-1][:top_k]
#
#             run_imp = np.zeros(p, dtype=float)
#
#             # Stage-2: Permutation on Top-K
#             if len(test_idx) < 2:
#                 # fallback: MDI (keep non-negative)
#                 if mdi is not None and len(mdi) == p:
#                     run_imp[top_idx] = np.maximum(mdi[top_idx], 0.0)
#                 all_imps.append(run_imp)
#                 continue
#
#             X_train_top = X_train_s[:, top_idx]
#             X_test_top  = X_test_s[:, top_idx]
#
#             rf_top = RandomForestRegressor(
#                 n_estimators=rf_n_estimators,
#                 max_depth=rf_max_depth,
#                 random_state=seed,
#                 n_jobs=1
#             )
#             rf_top.fit(X_train_top, y_train)
#
#             perm = permutation_importance(
#                 rf_top,
#                 X_test_top,
#                 y_test,
#                 n_repeats=n_perm_repeats,
#                 random_state=seed,
#                 scoring=scoring
#             )
#             run_imp[top_idx] = perm.importances_mean
#             all_imps.append(run_imp)
#
#     all_imps = np.array(all_imps)
#     mean_imp = np.nan_to_num(all_imps.mean(axis=0), nan=0.0, posinf=0.0, neginf=0.0)
#     std_imp  = np.nan_to_num(all_imps.std(axis=0),  nan=0.0, posinf=0.0, neginf=0.0)
#
#     return {
#         "features": feature_list,
#         "avg_importance": mean_imp,
#         "std_importance": std_imp,
#         "group": group_name
#     }
#
#
# def create_importance_df(results: dict) -> pd.DataFrame:
#     out = pd.DataFrame({
#         "Feature": results["features"],
#         "Mean_Importance": results["avg_importance"],
#         "Std_Importance": results["std_importance"]
#     }).sort_values("Mean_Importance", ascending=False)
#     out["Rank"] = range(1, len(out) + 1)
#     out["Cumulative_Importance"] = out["Mean_Importance"].cumsum()
#     return out
#
#
# # =========================
# # 3) Plotting (single-city OR row in a global grid)
# # =========================
# def plot_city_results_sci(
#     city_name: str,
#     df_year,
#     all_df,
#     udl_df,
#     eeq_df,
#     out_png=None,
#     topk_all: int = 10,
#     topk_group: int = 10,
#     dpi: int = 600,
#     show: bool = False,
#     english: bool = True,
#     axes_row=None,
#     set_col_titles: bool = False,
#     xmax_global: float = None,
#     ccd_ylim_global=None,
# ):
#     """
#     If axes_row is None: standalone single-city figure.
#     If axes_row is provided (len=5): draw in given axes row for a global grid.
#
#     Columns:
#       0=All barh, 1=UDL barh, 2=EEQ barh, 3=CCD, 4=Cumulative (normalized)
#     """
#
#     plt.rcParams.update({
#         "font.family": "DejaVu Sans",
#         "font.size": 10,
#         "axes.titlesize": 11,
#         "axes.labelsize": 10,
#         "xtick.labelsize": 9,
#         "ytick.labelsize": 9,
#         "legend.fontsize": 8,
#         "axes.linewidth": 1.0,
#     })
#
#     # Okabe-Ito palette
#     C_ALL = "#0072B2"
#     C_UDL = "#E69F00"
#     C_EEQ = "#009E73"
#     C_CCD = "#D55E00"
#     C_80  = "#CC79A7"
#     GRID  = "#D0D0D0"
#
#     years = df_year.index.tolist()
#     ccd = df_year["CCD"].values
#
#     def prep_top(df_imp, k):
#         d = df_imp.copy().head(k)
#         return d.iloc[::-1]
#
#     top_all = prep_top(all_df, topk_all)
#     top_udl = prep_top(udl_df, min(topk_group, len(udl_df)))
#     top_eeq = prep_top(eeq_df, min(topk_group, len(eeq_df)))
#
#     top_all_vals = np.clip(top_all["Mean_Importance"].values, 0, None)
#     top_udl_vals = np.clip(top_udl["Mean_Importance"].values, 0, None)
#     top_eeq_vals = np.clip(top_eeq["Mean_Importance"].values, 0, None)
#
#     xmax_local = max(top_all_vals.max(initial=0), top_udl_vals.max(initial=0), top_eeq_vals.max(initial=0))
#     xmax_local = xmax_local * 1.12 if xmax_local > 0 else 1.0
#     xmax = float(xmax_global) if xmax_global is not None else xmax_local
#
#     if english:
#         col_titles = [
#             f"Top-{topk_all} Drivers (All)",
#             "UDL Drivers (X1–X10)",
#             "EEQ Drivers (X11–X22)",
#             "CCD Time Series",
#             "Cumulative Contribution",
#         ]
#         xlab = "Permutation Importance (mean)"
#         ylab_cum = "Cum. Contribution"
#     else:
#         col_titles = [
#             f"综合 Top-{topk_all} 驱动因子（全指标）",
#             "UDL 驱动因子（X1–X10）",
#             "EEQ 驱动因子（X11–X22）",
#             "CCD 年际变化",
#             "累计贡献率",
#         ]
#         xlab = "Permutation Importance（均值）"
#         ylab_cum = "累计贡献率"
#
#     # axes select
#     if axes_row is None:
#         fig, axes = plt.subplots(2, 3, figsize=(14.5, 8.5))
#         ax_all = axes[0, 0]
#         ax_udl = axes[0, 1]
#         ax_ccd = axes[0, 2]
#         ax_eeq = axes[1, 0]
#         ax_cum = axes[1, 2]
#         axes[1, 1].axis("off")
#         created_fig = True
#     else:
#         ax_all, ax_udl, ax_eeq, ax_ccd, ax_cum = axes_row
#         fig = ax_all.figure
#         created_fig = False
#
#     # titles
#     if set_col_titles:
#         ax_all.set_title(col_titles[0], pad=6)
#         ax_udl.set_title(col_titles[1], pad=6)
#         ax_eeq.set_title(col_titles[2], pad=6)
#         ax_ccd.set_title(col_titles[3], pad=6)
#         ax_cum.set_title(col_titles[4], pad=6)
#     elif created_fig:
#         ax_all.set_title(f"{city_name}: {col_titles[0]}", pad=6)
#         ax_udl.set_title(f"{city_name}: {col_titles[1]}", pad=6)
#         ax_eeq.set_title(f"{city_name}: {col_titles[2]}", pad=6)
#         ax_ccd.set_title(f"{city_name}: {col_titles[3]}", pad=6)
#         ax_cum.set_title(f"{city_name}: {col_titles[4]}", pad=6)
#
#     def barh_plot(ax, df_top, vals, color, show_xlabel: bool, show_ylabel: bool):
#         ax.barh(df_top["Feature"].values, vals, color=color, alpha=0.95, edgecolor="none")
#         ax.set_xlim(0, xmax)
#         ax.grid(axis="x", color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
#         ax.grid(axis="y", visible=False)
#         for spine in ["top", "right"]:
#             ax.spines[spine].set_visible(False)
#         ax.set_xlabel(xlab if show_xlabel else "")
#         if not show_ylabel:
#             ax.set_ylabel("")
#
#     show_xlabel = created_fig
#     barh_plot(ax_all, top_all, top_all_vals, C_ALL, show_xlabel, True)
#     barh_plot(ax_udl, top_udl, top_udl_vals, C_UDL, show_xlabel, False)
#     barh_plot(ax_eeq, top_eeq, top_eeq_vals, C_EEQ, show_xlabel, True)
#
#     # row label
#     if not created_fig:
#         ax_all.set_ylabel(city_name, fontsize=11, rotation=0, labelpad=40, va="center")
#
#     # CCD
#     ax_ccd.plot(years, ccd, marker="o", linewidth=2.0, color=C_CCD, label="CCD")
#     ax_ccd.grid(color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
#     ax_ccd.set_xticks(years)
#     ax_ccd.tick_params(axis="x", rotation=35)
#     for spine in ["top", "right"]:
#         ax_ccd.spines[spine].set_visible(False)
#
#     if ccd_ylim_global is not None:
#         ax_ccd.set_ylim(ccd_ylim_global)
#
#     if created_fig:
#         ax_ccd.set_xlabel("Year")
#         ax_ccd.set_ylabel("CCD")
#         ax_ccd.legend(loc="best", frameon=True)
#     else:
#         ax_ccd.set_xlabel("")
#         ax_ccd.set_ylabel("")
#         ax_ccd.legend(loc="upper left", frameon=True)
#
#     # cumulative (normalized)
#     def cum_ratio(df_imp):
#         imp = np.clip(df_imp["Mean_Importance"].values, 0, None)
#         s = imp.sum()
#         if s <= 0:
#             return np.zeros_like(imp)
#         return np.cumsum(imp) / s
#
#     cum_all = cum_ratio(all_df)
#     cum_udl = cum_ratio(udl_df)
#     cum_eeq = cum_ratio(eeq_df)
#
#     ax_cum.plot(range(1, len(cum_all) + 1), cum_all, marker="o", linewidth=1.8, color=C_ALL, label="All")
#     ax_cum.plot(range(1, len(cum_udl) + 1), cum_udl, marker="s", linewidth=1.8, color=C_UDL, label="UDL")
#     ax_cum.plot(range(1, len(cum_eeq) + 1), cum_eeq, marker="^", linewidth=1.8, color=C_EEQ, label="EEQ")
#     ax_cum.axhline(0.8, color=C_80, linestyle="--", linewidth=1.3, label="80%")
#
#     ax_cum.set_ylim(0, 1.02)
#     max_len = max(len(cum_all), len(cum_udl), len(cum_eeq))
#     ax_cum.set_xlim(1, max_len + 0.5)
#     ax_cum.grid(color=GRID, linestyle="-", linewidth=0.8, alpha=0.7)
#     for spine in ["top", "right"]:
#         ax_cum.spines[spine].set_visible(False)
#
#     if created_fig:
#         ax_cum.set_xlabel("Number of Features")
#         ax_cum.set_ylabel(ylab_cum)
#         ax_cum.legend(loc="lower right", frameon=True)
#     else:
#         ax_cum.set_xlabel("")
#         ax_cum.set_ylabel("")
#         if ax_cum.get_legend() is not None:
#             ax_cum.get_legend().remove()
#
#     # save/show
#     if created_fig and out_png:
#         plt.savefig(out_png, dpi=dpi, bbox_inches="tight")
#         if show:
#             plt.show()
#         plt.close(fig)
#
#
# def plot_all_cities_grid_7x5(
#     city_results: list,
#     out_png: str,
#     dpi: int = 600,
#     english: bool = True,
#     topk_all: int = 10,
#     topk_group: int = 10,
# ):
#     n_rows = len(city_results)
#     n_cols = 5
#
#     # global xmax
#     def top_vals(df_imp, k):
#         d = df_imp.head(k)
#         v = np.clip(d["Mean_Importance"].values, 0, None)
#         return v.max(initial=0)
#
#     xmax_global = 0.0
#     for item in city_results:
#         xmax_global = max(
#             xmax_global,
#             top_vals(item["all_df"], topk_all),
#             top_vals(item["udl_df"], min(topk_group, len(item["udl_df"]))),
#             top_vals(item["eeq_df"], min(topk_group, len(item["eeq_df"]))),
#         )
#     xmax_global = xmax_global * 1.12 if xmax_global > 0 else 1.0
#
#     # global CCD ylim
#     ccd_all = np.concatenate([item["df_year"]["CCD"].values for item in city_results])
#     y_min = float(np.min(ccd_all))
#     y_max = float(np.max(ccd_all))
#     pad = 0.05 * (y_max - y_min + 1e-9)
#     ccd_ylim_global = (y_min - pad, y_max + pad)
#
#     fig, axes = plt.subplots(
#         n_rows, n_cols,
#         figsize=(27, 3.6 * n_rows),
#         constrained_layout=True
#     )
#
#     for r, item in enumerate(city_results):
#         plot_city_results_sci(
#             city_name=item["city"],
#             df_year=item["df_year"],
#             all_df=item["all_df"],
#             udl_df=item["udl_df"],
#             eeq_df=item["eeq_df"],
#             out_png=None,
#             topk_all=topk_all,
#             topk_group=topk_group,
#             show=False,
#             english=english,
#             axes_row=axes[r, :],
#             set_col_titles=(r == 0),
#             xmax_global=xmax_global,
#             ccd_ylim_global=ccd_ylim_global
#         )
#
#         # only last row show xlabels
#         if r == n_rows - 1:
#             axes[r, 0].set_xlabel("Permutation Importance (mean)" if english else "Permutation Importance（均值）")
#             axes[r, 1].set_xlabel("Permutation Importance (mean)" if english else "Permutation Importance（均值）")
#             axes[r, 2].set_xlabel("Permutation Importance (mean)" if english else "Permutation Importance（均值）")
#             axes[r, 3].set_xlabel("Year" if english else "年份")
#             axes[r, 4].set_xlabel("Number of Features" if english else "特征数")
#
#     # global legend (bottom center)
#     h_ccd, l_ccd = axes[0, 3].get_legend_handles_labels()
#     h_cum, l_cum = axes[0, 4].get_legend_handles_labels()
#
#     seen, H, L = set(), [], []
#     for h, l in list(zip(h_ccd, l_ccd)) + list(zip(h_cum, l_cum)):
#         if l not in seen:
#             seen.add(l)
#             H.append(h)
#             L.append(l)
#
#     fig.legend(
#         H, L,
#         loc="lower center",
#         ncol=6,
#         frameon=True,
#         bbox_to_anchor=(0.5, -0.002)
#     )
#
#     plt.savefig(out_png, dpi=dpi, bbox_inches="tight")
#     plt.show()
#     plt.close(fig)
#
#
# # =========================
# # 4) Run all cities
# # =========================
# def run_all_cities(xlsx_path: str, out_dir: str):
#     os.makedirs(out_dir, exist_ok=True)
#
#     xls = pd.ExcelFile(xlsx_path)
#     sheet_names = xls.sheet_names
#
#     summary_rows = []
#     city_results = []   # ✅ 关键：放在循环外，收集7个城市结果
#
#     excel_writer = None
#     if SAVE_EXCEL_SUMMARY:
#         excel_writer = pd.ExcelWriter(os.path.join(out_dir, "RF_Importance_AllCities.xlsx"))
#
#     for city in sheet_names:
#         print(f"\n=== Processing city: {city} ===")
#         df_year = load_city_sheet_as_year_rows(xlsx_path, city)
#
#         all_features = UDL_FEATURES + EEQ_FEATURES
#
#         all_results = rf_timeaware_perm_importance(
#             df_year=df_year, feature_list=all_features, target_col=TARGET_COL,
#             group_name="All",
#             min_train_size=MIN_TRAIN_SIZE,
#             n_seed_repeats=N_SEED_REPEATS,
#             n_perm_repeats=N_PERM_REPEATS,
#             rf_n_estimators=RF_N_ESTIMATORS,
#             rf_max_depth=RF_MAX_DEPTH
#         )
#         udl_results = rf_timeaware_perm_importance(
#             df_year=df_year, feature_list=UDL_FEATURES, target_col=TARGET_COL,
#             group_name="UDL",
#             min_train_size=MIN_TRAIN_SIZE,
#             n_seed_repeats=N_SEED_REPEATS,
#             n_perm_repeats=N_PERM_REPEATS,
#             rf_n_estimators=RF_N_ESTIMATORS,
#             rf_max_depth=RF_MAX_DEPTH
#         )
#         eeq_results = rf_timeaware_perm_importance(
#             df_year=df_year, feature_list=EEQ_FEATURES, target_col=TARGET_COL,
#             group_name="EEQ",
#             min_train_size=MIN_TRAIN_SIZE,
#             n_seed_repeats=N_SEED_REPEATS,
#             n_perm_repeats=N_PERM_REPEATS,
#             rf_n_estimators=RF_N_ESTIMATORS,
#             rf_max_depth=RF_MAX_DEPTH
#         )
#
#         all_df = create_importance_df(all_results)
#         udl_df = create_importance_df(udl_results)
#         eeq_df = create_importance_df(eeq_results)
#
#         city_safe = str(city).replace("/", "_").replace("\\", "_")
#
#         # per-city CSV
#         all_df.to_csv(os.path.join(out_dir, f"{city_safe}_All_Importance.csv"), index=False)
#         udl_df.to_csv(os.path.join(out_dir, f"{city_safe}_UDL_Importance.csv"), index=False)
#         eeq_df.to_csv(os.path.join(out_dir, f"{city_safe}_EEQ_Importance.csv"), index=False)
#
#         # per-city Excel (optional)
#         if excel_writer is not None:
#             all_df.to_excel(excel_writer, sheet_name=f"{city_safe}_All", index=False)
#             udl_df.to_excel(excel_writer, sheet_name=f"{city_safe}_UDL", index=False)
#             eeq_df.to_excel(excel_writer, sheet_name=f"{city_safe}_EEQ", index=False)
#
#         # per-city figure (optional)
#         if SAVE_PER_CITY_FIG:
#             out_png_city = os.path.join(out_dir, f"{city_safe}_RF_Drivers.png")
#             plot_city_results_sci(
#                 city_name=city_safe,
#                 df_year=df_year,
#                 all_df=all_df,
#                 udl_df=udl_df,
#                 eeq_df=eeq_df,
#                 out_png=out_png_city,
#                 topk_all=10,
#                 topk_group=10,
#                 dpi=600,
#                 show=False,
#                 english=True
#             )
#
#         # ✅ collect for 7×5 figure
#         city_results.append({
#             "city": city_safe,
#             "df_year": df_year,
#             "all_df": all_df,
#             "udl_df": udl_df,
#             "eeq_df": eeq_df
#         })
#
#         # summary top-3
#         def topk(df_imp, k=3):
#             return [(r["Feature"], r["Mean_Importance"], r["Std_Importance"]) for _, r in df_imp.head(k).iterrows()]
#
#         for grp, df_imp in [("All", all_df), ("UDL", udl_df), ("EEQ", eeq_df)]:
#             for rank, (feat, mean_i, std_i) in enumerate(topk(df_imp, 3), start=1):
#                 summary_rows.append({
#                     "City": city_safe,
#                     "Group": grp,
#                     "Rank": rank,
#                     "Feature": feat,
#                     "Mean_Importance": float(mean_i),
#                     "Std_Importance": float(std_i)
#                 })
#
#     if excel_writer is not None:
#         excel_writer.close()
#
#     # ✅ 7×5 total figure (AFTER loop)
#     out_png_grid = os.path.join(out_dir, "AllCities_7x5_RFDrivers.png")
#     plot_all_cities_grid_7x5(
#         city_results=city_results,
#         out_png=out_png_grid,
#         dpi=600,
#         english=True,
#         topk_all=10,
#         topk_group=10
#     )
#
#     summary_df = pd.DataFrame(summary_rows)
#     summary_df.to_csv(os.path.join(out_dir, "AllCities_TopDrivers_Summary.csv"), index=False)
#
#     print(f"\n✓ Done. Results saved to: {out_dir}")
#     print("  - Per-city CSVs (+ optional per-city figs)")
#     print("  - AllCities_TopDrivers_Summary.csv")
#     print("  - AllCities_7x5_RFDrivers.png")
#     if SAVE_EXCEL_SUMMARY:
#         print("  - RF_Importance_AllCities.xlsx")
#
#
# if __name__ == "__main__":
#     run_all_cities(INPUT_XLSX, OUT_DIR)

#******************************************************************************#

import os
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.inspection import permutation_importance


# =========================
# User config
# =========================
INPUT_XLSX = "驱动因素输入V3.xlsx"   # 改成你的Excel文件名
OUT_DIR = "RF_DrivingFactor_Results"

SAVE_EXCEL_SUMMARY = True   # 是否保存总Excel
SAVE_PER_CITY_FIG = True    # 是否保存每个城市的单独图

MIN_TRAIN_SIZE = 4
N_SEED_REPEATS = 10
N_PERM_REPEATS = 10

RF_N_ESTIMATORS = 50
RF_MAX_DEPTH = 2

# 指标分组
UDL_FEATURES = [f"X{i}" for i in range(1, 11)]      # X1-X10
EEQ_FEATURES = [f"X{i}" for i in range(11, 23)]     # X11-X22
TARGET_COL = "CCD"


# =========================
# 1) Data loader
# =========================
def load_city_sheet_as_year_rows(xlsx_path: str, sheet_name: str) -> pd.DataFrame:
    """
    读取单个城市sheet：
    - 期望格式：行=指标（X1..X22, CCD），列=年份（2014..2023..）
    - 返回格式：行=年份，列=特征（X1..X22）+ CCD
    """
    raw = pd.read_excel(xlsx_path, sheet_name=sheet_name, index_col=0)

    # 行名清洗
    raw.index = raw.index.astype(str).str.strip()

    # 去掉全空行/列
    raw = raw.dropna(axis=0, how="all").dropna(axis=1, how="all")

    # 列名尽量转成年份
    new_cols = []
    for c in raw.columns:
        c_str = str(c).strip()
        try:
            new_cols.append(int(c_str))
        except Exception:
            new_cols.append(c_str)
    raw.columns = new_cols

    # 检查必须存在的指标行
    required_rows = UDL_FEATURES + EEQ_FEATURES + [TARGET_COL]
    missing = [r for r in required_rows if r not in raw.index]
    if missing:
        raise ValueError(f"[{sheet_name}] 缺失行指标: {missing}。请检查 sheet 行名是否为 X1..X22 与 CCD。")

    # 只取需要的指标
    raw_use = raw.loc[required_rows, :].copy()

    # 转数值，非法值转 NaN
    raw_use = raw_use.apply(pd.to_numeric, errors="coerce")

    # 检查非法值/缺失值
    if raw_use.isna().any().any():
        bad_pos = np.where(raw_use.isna())
        bad_info = []
        for i, j in zip(bad_pos[0], bad_pos[1]):
            bad_info.append(f"(指标={raw_use.index[i]}, 年份={raw_use.columns[j]})")
        raise ValueError(
            f"[{sheet_name}] 存在非数值或缺失内容，位置如下：\n" +
            "\n".join(bad_info[:20]) +
            ("\n..." if len(bad_info) > 20 else "")
        )

    # 防止0值导致后续奇异
    raw_use = raw_use.replace(0.0, 1e-7)
    raw_use = raw_use.clip(lower=1e-7)

    # 转成 年份 × 指标
    df_year = raw_use.T
    df_year.index.name = "Year"

    # 年份排序
    try:
        df_year = df_year.sort_index()
    except Exception:
        pass

    return df_year


# =========================
# 2) Time-aware RF + permutation importance
# =========================
def rf_timeaware_perm_importance(
    df_year: pd.DataFrame,
    feature_list: list,
    target_col: str,
    group_name: str,
    min_train_size: int = 4,
    n_seed_repeats: int = 10,
    n_perm_repeats: int = 10,
    rf_n_estimators: int = 50,
    rf_max_depth: int = 2,
    scoring: str = "neg_mean_squared_error",
):
    """
    Two-stage, time-aware forward-chaining CV importance.
    Returns:
      dict {features, avg_importance, std_importance, group}
    """

    X_all = df_year[feature_list].copy()
    y_all = df_year[target_col].copy()

    n = len(df_year)
    p = len(feature_list)

    if n < min_train_size + 1:
        raise ValueError(
            f"{group_name}: n={n} too small for min_train_size={min_train_size} "
            f"(need >= {min_train_size + 1})."
        )

    # 内部测试窗口长度
    test_horizon = 2
    if n - min_train_size < 2:
        test_horizon = 1

    folds = []
    for t in range(min_train_size - 1, n - 1):
        test_start = t + 1
        test_end = min(n, test_start + test_horizon)
        test_idx = list(range(test_start, test_end))
        if len(test_idx) == 0:
            continue
        folds.append((list(range(0, t + 1)), test_idx))

    if len(folds) == 0:
        raise RuntimeError(f"{group_name}: no valid folds constructed.")

    # 两阶段筛选 top_k
    if p <= 6:
        top_k = p
    elif p <= 12:
        top_k = 6
    else:
        top_k = 8

    all_imps = []

    for seed in range(n_seed_repeats):
        for train_idx, test_idx in folds:
            X_train = X_all.iloc[train_idx].values
            X_test = X_all.iloc[test_idx].values
            y_train = y_all.iloc[train_idx].values
            y_test = y_all.iloc[test_idx].values

            scaler = StandardScaler()
            X_train_s = scaler.fit_transform(X_train)
            X_test_s = scaler.transform(X_test)

            rf = RandomForestRegressor(
                n_estimators=rf_n_estimators,
                max_depth=rf_max_depth,
                random_state=seed,
                n_jobs=1
            )
            rf.fit(X_train_s, y_train)

            # Stage-1: MDI筛选
            mdi = getattr(rf, "feature_importances_", None)
            if mdi is None or len(mdi) != p or (mdi.sum() <= 0):
                top_idx = np.arange(p)
            else:
                top_idx = np.argsort(mdi)[::-1][:top_k]

            run_imp = np.zeros(p, dtype=float)

            # 如果测试集太短，则退化为MDI
            if len(test_idx) < 2:
                if mdi is not None and len(mdi) == p:
                    run_imp[top_idx] = np.maximum(mdi[top_idx], 0.0)
                all_imps.append(run_imp)
                continue

            X_train_top = X_train_s[:, top_idx]
            X_test_top = X_test_s[:, top_idx]

            rf_top = RandomForestRegressor(
                n_estimators=rf_n_estimators,
                max_depth=rf_max_depth,
                random_state=seed,
                n_jobs=1
            )
            rf_top.fit(X_train_top, y_train)

            perm = permutation_importance(
                rf_top,
                X_test_top,
                y_test,
                n_repeats=n_perm_repeats,
                random_state=seed,
                scoring=scoring
            )
            run_imp[top_idx] = perm.importances_mean
            all_imps.append(run_imp)

    all_imps = np.array(all_imps)
    mean_imp = np.nan_to_num(all_imps.mean(axis=0), nan=0.0, posinf=0.0, neginf=0.0)
    std_imp = np.nan_to_num(all_imps.std(axis=0), nan=0.0, posinf=0.0, neginf=0.0)

    return {
        "features": feature_list,
        "avg_importance": mean_imp,
        "std_importance": std_imp,
        "group": group_name
    }


def create_importance_df(results: dict) -> pd.DataFrame:
    out = pd.DataFrame({
        "Feature": results["features"],
        "Mean_Importance": results["avg_importance"],
        "Std_Importance": results["std_importance"]
    }).sort_values("Mean_Importance", ascending=False)

    out["Rank"] = range(1, len(out) + 1)
    out["Cumulative_Importance"] = out["Mean_Importance"].cumsum()
    return out


# =========================
# 3) Plotting: 单城市 2×2 图（不画 CCD）
# =========================
def plot_city_results_single(
    city_name: str,
    df_year: pd.DataFrame,
    all_df: pd.DataFrame,
    udl_df: pd.DataFrame,
    eeq_df: pd.DataFrame,
    out_png: str,
    topk_all: int = 10,
    topk_group: int = 10,
    dpi: int = 600,
    english: bool = True,
):
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.labelsize": 10,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 8,
        "axes.linewidth": 0.8,
    })

    # 若要中文显示，可取消下面两行注释，并设 english=False
    # plt.rcParams["font.sans-serif"] = ["SimHei"]
    # plt.rcParams["axes.unicode_minus"] = False

    # 配色
    C_ALL = "#1f77b4"
    C_UDL = "#E69F00"
    C_EEQ = "#009E73"
    C_80 = "#CC79A7"
    GRID = "#D9D9D9"

    def prep_top(df_imp, k):
        d = df_imp.copy().head(k)
        d = d[d["Mean_Importance"] > 0]
        if len(d) == 0:
            d = df_imp.copy().head(min(k, len(df_imp)))
        return d.iloc[::-1]

    top_all = prep_top(all_df, topk_all)
    top_udl = prep_top(udl_df, topk_group)
    top_eeq = prep_top(eeq_df, topk_group)

    max_all = np.clip(top_all["Mean_Importance"].values, 0, None).max() if len(top_all) else 0
    max_udl = np.clip(top_udl["Mean_Importance"].values, 0, None).max() if len(top_udl) else 0
    max_eeq = np.clip(top_eeq["Mean_Importance"].values, 0, None).max() if len(top_eeq) else 0
    xmax = max(max_all, max_udl, max_eeq)
    xmax = xmax * 1.12 if xmax > 0 else 1.0

    if english:
        title_all = "Top-10 Important Indicators (All)"
        title_udl = "Important UDL Indicators (X1–X10)"
        title_eeq = "Important EEQ Indicators (X11–X22)"
        title_cum = "Cumulative Importance Contribution"
        xlab_bar = "Permutation Importance (mean)"
        xlab_num = "Number of Features"
        ylab_cum = "Contribution Ratio"
    else:
        title_all = "Top-10 驱动因子（全部）"
        title_udl = "UDL 驱动因子（X1–X10）"
        title_eeq = "EEQ 驱动因子（X11–X22）"
        title_cum = "累计贡献率"
        xlab_bar = "Permutation Importance（均值）"
        xlab_num = "特征数"
        ylab_cum = "贡献率"

    # 2×2 布局
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    plt.subplots_adjust(wspace=0.28, hspace=0.32)

    ax_all = axes[0, 0]
    ax_udl = axes[0, 1]
    ax_eeq = axes[1, 0]
    ax_cum = axes[1, 1]

    def style_barh(ax, df_top, color, title):
        vals = np.clip(df_top["Mean_Importance"].values, 0, None)
        ax.barh(df_top["Feature"].values, vals, color=color, edgecolor="none", alpha=0.95)
        ax.set_title(title, pad=8)
        ax.set_xlim(0, xmax)
        ax.set_xlabel(xlab_bar)
        ax.grid(axis="x", linestyle="--", linewidth=0.6, color=GRID, alpha=0.9)
        ax.grid(axis="y", visible=False)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

    style_barh(ax_all, top_all, C_ALL, title_all)
    style_barh(ax_udl, top_udl, C_UDL, title_udl)
    style_barh(ax_eeq, top_eeq, C_EEQ, title_eeq)

    # 累计贡献率
    def cum_ratio(df_imp):
        imp = np.clip(df_imp["Mean_Importance"].values, 0, None)
        s = imp.sum()
        if s <= 0:
            return np.zeros(len(imp))
        return np.cumsum(imp) / s

    cum_all = cum_ratio(all_df)
    cum_udl = cum_ratio(udl_df)
    cum_eeq = cum_ratio(eeq_df)

    ax_cum.plot(
        range(1, len(cum_all) + 1), cum_all,
        marker="o", linewidth=1.6, markersize=3.5, color=C_ALL, label="All"
    )
    ax_cum.plot(
        range(1, len(cum_udl) + 1), cum_udl,
        marker="s", linewidth=1.6, markersize=3.5, color=C_UDL, label="UDL"
    )
    ax_cum.plot(
        range(1, len(cum_eeq) + 1), cum_eeq,
        marker="^", linewidth=1.6, markersize=3.5, color=C_EEQ, label="EEQ"
    )
    ax_cum.axhline(0.8, color=C_80, linestyle="--", linewidth=1.2, label="80%")

    ax_cum.set_title(title_cum, pad=8)
    ax_cum.set_xlabel(xlab_num)
    ax_cum.set_ylabel(ylab_cum)
    ax_cum.set_ylim(0, 1.03)
    ax_cum.set_xlim(1, max(len(cum_all), len(cum_udl), len(cum_eeq)) + 0.5)
    ax_cum.grid(True, linestyle="--", linewidth=0.6, color=GRID, alpha=0.9)
    for spine in ["top", "right"]:
        ax_cum.spines[spine].set_visible(False)
    ax_cum.legend(loc="lower right", frameon=False)

    fig.suptitle(f"{city_name}", fontsize=16, y=0.98)
    plt.savefig(out_png, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


# =========================
# 4) Run all cities
# =========================
def run_all_cities(xlsx_path: str, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)

    xls = pd.ExcelFile(xlsx_path)
    sheet_names = xls.sheet_names

    summary_rows = []

    excel_writer = None
    if SAVE_EXCEL_SUMMARY:
        excel_writer = pd.ExcelWriter(os.path.join(out_dir, "RF_Importance_AllCities.xlsx"))

    for city in sheet_names:
        print(f"\n=== Processing city: {city} ===")
        df_year = load_city_sheet_as_year_rows(xlsx_path, city)

        all_features = UDL_FEATURES + EEQ_FEATURES

        all_results = rf_timeaware_perm_importance(
            df_year=df_year,
            feature_list=all_features,
            target_col=TARGET_COL,
            group_name="All",
            min_train_size=MIN_TRAIN_SIZE,
            n_seed_repeats=N_SEED_REPEATS,
            n_perm_repeats=N_PERM_REPEATS,
            rf_n_estimators=RF_N_ESTIMATORS,
            rf_max_depth=RF_MAX_DEPTH
        )

        udl_results = rf_timeaware_perm_importance(
            df_year=df_year,
            feature_list=UDL_FEATURES,
            target_col=TARGET_COL,
            group_name="UDL",
            min_train_size=MIN_TRAIN_SIZE,
            n_seed_repeats=N_SEED_REPEATS,
            n_perm_repeats=N_PERM_REPEATS,
            rf_n_estimators=RF_N_ESTIMATORS,
            rf_max_depth=RF_MAX_DEPTH
        )

        eeq_results = rf_timeaware_perm_importance(
            df_year=df_year,
            feature_list=EEQ_FEATURES,
            target_col=TARGET_COL,
            group_name="EEQ",
            min_train_size=MIN_TRAIN_SIZE,
            n_seed_repeats=N_SEED_REPEATS,
            n_perm_repeats=N_PERM_REPEATS,
            rf_n_estimators=RF_N_ESTIMATORS,
            rf_max_depth=RF_MAX_DEPTH
        )

        all_df = create_importance_df(all_results)
        udl_df = create_importance_df(udl_results)
        eeq_df = create_importance_df(eeq_results)

        city_safe = str(city).replace("/", "_").replace("\\", "_")

        # 保存CSV
        all_df.to_csv(os.path.join(out_dir, f"{city_safe}_All_Importance.csv"), index=False)
        udl_df.to_csv(os.path.join(out_dir, f"{city_safe}_UDL_Importance.csv"), index=False)
        eeq_df.to_csv(os.path.join(out_dir, f"{city_safe}_EEQ_Importance.csv"), index=False)

        # 保存Excel
        if excel_writer is not None:
            all_df.to_excel(excel_writer, sheet_name=f"{city_safe}_All", index=False)
            udl_df.to_excel(excel_writer, sheet_name=f"{city_safe}_UDL", index=False)
            eeq_df.to_excel(excel_writer, sheet_name=f"{city_safe}_EEQ", index=False)

        # 保存每个城市的2×2图
        if SAVE_PER_CITY_FIG:
            out_png_city = os.path.join(out_dir, f"{city_safe}_RF_Drivers_2x2.png")
            plot_city_results_single(
                city_name=city_safe,
                df_year=df_year,
                all_df=all_df,
                udl_df=udl_df,
                eeq_df=eeq_df,
                out_png=out_png_city,
                topk_all=10,
                topk_group=10,
                dpi=600,
                english=True
            )

        # 汇总 top-3
        def topk(df_imp, k=3):
            return [
                (r["Feature"], r["Mean_Importance"], r["Std_Importance"])
                for _, r in df_imp.head(k).iterrows()
            ]

        for grp, df_imp in [("All", all_df), ("UDL", udl_df), ("EEQ", eeq_df)]:
            for rank, (feat, mean_i, std_i) in enumerate(topk(df_imp, 3), start=1):
                summary_rows.append({
                    "City": city_safe,
                    "Group": grp,
                    "Rank": rank,
                    "Feature": feat,
                    "Mean_Importance": float(mean_i),
                    "Std_Importance": float(std_i)
                })

    if excel_writer is not None:
        excel_writer.close()

    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(os.path.join(out_dir, "AllCities_TopDrivers_Summary.csv"), index=False)

    print(f"\n✓ Done. Results saved to: {out_dir}")
    print("  - 每个城市各自一张 2×2 高清图（不含CCD time series）")
    print("  - 每个城市的CSV结果")
    print("  - AllCities_TopDrivers_Summary.csv")
    if SAVE_EXCEL_SUMMARY:
        print("  - RF_Importance_AllCities.xlsx")


if __name__ == "__main__":
    run_all_cities(INPUT_XLSX, OUT_DIR)